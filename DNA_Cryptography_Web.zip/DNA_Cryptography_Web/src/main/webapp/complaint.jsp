<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
<title>Submit Complaint</title>

<style>
body {
    font-family: Arial;
    background: #f0f2f5;
}

.container {
    width: 400px;
    margin: 60px auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
}

textarea {
    width: 100%;
    height: 100px;
    padding: 10px;
    margin-top: 10px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

input[type="file"] {
    margin-top: 10px;
}

button {
    width: 100%;
    padding: 10px;
    margin-top: 15px;
    background: #3498db;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background: #217dbb;
}

.msg {
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 8px;
    text-align: center;
}

.success {
    background: #d4edda;
    color: #155724;
}

.error {
    background: #f8d7da;
    color: #721c24;
}
</style>

<script>
function validateForm() {
    var msg = document.getElementsByName("message")[0].value.trim();
    var file = document.getElementsByName("file")[0].value;

    if (msg === "" && file === "") {
        alert("Please enter message or choose a file!");
        return false;
    }
    return true;
}
</script>

</head>

<body>

<div class="container">

<h2>📢 Submit Complaint</h2>

<%
String success = request.getParameter("success");
String error = request.getParameter("error");

if(success != null){
%>
    <div class="msg success">✅ Complaint sent successfully!</div>
<%
}

if(error != null){
%>
    <div class="msg error">❌ Please enter message or upload file</div>
<%
}
%>

<form action="UploadServlet" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">

    <!-- MUST BE ADMIN -->
    <input type="hidden" name="receiver" value="admin">

    <label>Enter Complaint:</label><br>
    <textarea name="message" placeholder="Type your complaint..."></textarea><br><br>

    <label>Attach File (optional):</label><br>
    <input type="file" name="file"><br><br>

    <button type="submit">Submit Complaint</button>

</form>

</div>

</body>
</html>