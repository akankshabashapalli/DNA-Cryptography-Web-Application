<%@ page contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Register – DNA Cryptography Cloud</title>
    <style>
        body { margin: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f0f2f5; color: #333; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        header h1 { margin: 0; font-size: 1.8em; }
        nav.menu { background: #34495e; padding: 10px; text-align: center; }
        nav.menu a { color: white; margin: 0 15px; text-decoration: none; font-weight: 500; }
        nav.menu a:hover { color: #f1c40f; }
        .container { margin: 20px auto; max-width: 480px; padding: 0 15px; }
        .card { background: white; border-radius: 10px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin: 15px 0; }
        input, select, textarea {
            width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;
        }
        input:focus, select:focus { outline: none; border-color: #2c3e50; box-shadow: 0 0 0 2px rgba(44,62,80,0.2); }
        .btn { padding: 12px; background: #2c3e50; color: white; border: none; border-radius: 6px; cursor: pointer; width: 100%; font-weight: 500; }
        .btn:hover { opacity: 0.9; }
        .success-box {
            background: #e8f8f5; color: #1abc9c; padding: 15px; border-left: 5px solid #1abc9c;
            border-radius: 6px; margin-bottom: 20px; font-weight: 500;
        }
    </style>
</head>
<body>
<header>
    <h1>🧬 DNA Cryptography Cloud System – Register</h1>
</header>

<nav class="menu">
    <a href="index.jsp">🏠 Home</a>
    <a href="index.jsp">🔐 Login</a>
    <a href="contact.jsp">📞 Contact</a>
</nav>

<div class="container">
    <%
    String msg = request.getParameter("msg");
    if ("success".equals(msg)) {
    %>
    <div class="success-box">🎉 Registration Successful! You can now login.</div>
    <%
    } else if ("error".equals(msg)) {
    %>
    <div style="background:#fee; color:#c33; padding:15px; border-left:5px solid #e74c3c; border-radius:6px; margin-bottom:20px;">
        ❌ Registration failed. Try again.
    </div>
    <%
    }
    %>

    <div class="card">
        <h2>Create New Account</h2>
        <form action="RegisterServlet" method="post">
           <input type="text" name="fname" placeholder="First Name" required>
<input type="text" name="lname" placeholder="Last Name" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirmPassword" placeholder="Confirm Password" required>
            
            <!-- FIXED: Changed userType to role -->
            <select name="role" required>
                <option value="">Select Role</option>
                <option value="admin">👨‍💼 Admin</option>
                <option value="user">👤 User</option>
                <option value="owner">💼 Data Owner</option>
            </select>

            <input type="email" name="email" placeholder="Email" required>
            <input type="text" name="phone" placeholder="Phone" required>
            <textarea name="address" placeholder="Address" rows="3" required></textarea>
            <input type="date" name="dob" required>
            <select name="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>
            <input type="text" name="pincode" placeholder="Pincode" required>
            <button type="submit" class="btn">Register Account</button>
        </form>
    </div>
</div>
</body>
</html>