<style>
    body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
    header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
    nav.menu { background: #34495e; padding: 10px; text-align: center; }
    nav.menu a { color: white; margin: 0 15px; text-decoration: none; }
    .menu a:hover { color: #f1c40f; }
    .container { margin: 20px auto; max-width: 800px; padding: 0 15px; }
    .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .btn-large { padding: 12px 20px; background: #2980b9; color: white; border: none; border-radius: 8px; cursor: pointer; margin: 5px; }
</style>