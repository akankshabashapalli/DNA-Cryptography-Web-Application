<%@ page import="java.util.*, dnaweb.Message" %>

<%
String user = (String) session.getAttribute("user");
if(user == null){
    response.sendRedirect("index.jsp");
    return;
}

List<Message> messages = (List<Message>) request.getAttribute("messages");
if(messages == null) messages = new ArrayList<>();

String result = (String) request.getAttribute("decryptedText");
%>

<h2>Welcome <%= user %></h2>

<% if(result != null){ %>
    <h3>Decrypted Message: <%= result %></h3>
<% } %>

<table border="1">
<tr>
<th>Sender</th>
<th>DNA</th>
<th>Status</th>
<th>Time</th>
<th>Action</th>
</tr>

<%
for(Message m : messages){
%>

<tr>
<td><%= m.getSender() %></td>
<td><%= m.getMessageText() %></td>
<td><%= m.getStatus() %></td>
<td><%= m.getCreatedAt() %></td>

<td>
<form action="MessageDecryptServlet" method="post">
    <input type="hidden" name="dna"
           value="<%= m.getMessageText() %>">

    <input type="text" name="key"
           placeholder="Enter key" required>

    <button type="submit">Decrypt</button>
</form>
</td>
</tr>

<%
}
%>

</table>