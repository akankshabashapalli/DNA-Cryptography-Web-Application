<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String user = (String) session.getAttribute("user");
    String role = (String) session.getAttribute("role");
    if (user == null || !"owner".equals(role)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<html>
<head>
    <title>Upload & Encrypt File – Data Owner</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
        .menu { background: #34495e; padding: 10px; text-align: center; }
        .menu a { color: white; margin: 0 15px; text-decoration: none; }
        .container { margin: 20px auto; max-width: 600px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        label { display: block; margin: 8px 0 4px 0; }
        input { width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { padding: 10px 15px; background: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>

<header>
    <h1>DNA Cryptography Cloud – Data Owner Dashboard</h1>
</header>

<nav class="menu">
    <a href="index.jsp">Home</a>
    <a href="ownerDashboard.jsp">Dashboard</a>
    <a href="receiveFiles.jsp">Received Files</a>
    <a href="decryptFile.jsp">Decrypt File</a>
    <a href="logout.jsp">Logout</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Encrypt & Send File (Owner)</h2>

        <form action="FileEncryptServlet" method="post" enctype="multipart/form-data">
            <label>File:</label>
            <input type="file" name="file" required>

            <label>Key:</label>
            <input type="text" name="key" required>

            <label>Receiver:</label>
            <input type="text" name="receiver" required>

            <button type="submit">Encrypt & Send</button>
        </form>
    </div>
</div>

</body>
</html>