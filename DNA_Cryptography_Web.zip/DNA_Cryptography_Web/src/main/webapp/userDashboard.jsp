<%@ page contentType="text/html; charset=UTF-8" %>
<%@ page import="java.sql.*" %>
<%@ page import="dnaweb.DBConnection" %>

<%
String msg = request.getParameter("msg");
if ("success".equals(msg)) {
%>
<div id="msgBox" style="background:#4CAF50;color:white;padding:10px;margin:10px;border-radius:8px;">
    ✅ Message Sent Successfully!
</div>
<%
}


if ("deleted".equals(msg)) {
%>
<div id="msgBox" style="background:#f44336;color:white;padding:10px;margin:10px;border-radius:8px;">
    🗑 File moved to Trash
</div>



<%
} else if ("restored".equals(msg)) {
%>
<div id="msgBox" style="background:#4CAF50;color:white;padding:10px;margin:10px;border-radius:8px;">
    ♻ File Restored Successfully
</div>



<%
} else if ("permanent".equals(msg)) {
%>
<div id="msgBox" style="background:#000;color:white;padding:10px;margin:10px;border-radius:8px;">
    ❌ File Permanently Deleted
</div>



<%
} else if ("error".equals(msg)) {
%>
<div id="msgBox" style="background:#f44336;color:white;padding:10px;margin:10px;border-radius:8px;">
    ❌ Action Failed!
</div>


<%
}
%>

<%
String user = (String) session.getAttribute("user");
if (user == null) {
    response.sendRedirect("index.jsp");
    return;
}
%>

<html>
<head>
<title>User Dashboard</title>

<style>
body {
    margin:0;
    font-family:Segoe UI;
    background:#f4f7fb;
}

.header {
    background:white;
    padding:15px 30px;
    font-size:20px;
    font-weight:bold;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);
}

.container {
    padding:30px;
}

/* CARDS */
.cards {
    display:flex;
    gap:20px;
    flex-wrap:wrap;
    justify-content:center;
}

.card {
    background:white;
    width:180px;
    padding:20px;
    border-radius:12px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
    text-align:center;
}

button {
    width:100%;
    padding:10px;
    margin-top:10px;
    border:none;
    border-radius:8px;
    background:#4CAF50;
    color:white;
    cursor:pointer;
    font-weight:bold;
}

button:hover {
    background:#43a047;
}

.logout {
    background:#f44336;
}

.logout:hover {
    background:#d32f2f;
}

/* FILE BUTTON STYLE */
.file-box {
    width:60%;
    margin:40px auto;
}

.file-btn {
    width:100%;
    padding:12px;
    margin:10px 0;
    background:#2196F3;
    color:white;
    border:none;
    border-radius:8px;
    text-align:left;
    cursor:pointer;
    font-size:14px;
}

.file-btn:hover {
    background:#1976D2;
}
</style>
</head>

<body>

<div class="header">
    Welcome, <%= user %>
</div>

<div class="container">

<!-- 🔷 TOP CARDS -->
<div class="cards">

<div class="card">
    <h3>💬 Text</h3>
    <form action="sendText.jsp">
        <button>Send</button>
    </form>
</div>

<div class="card">
    <h3>📤 Send Data</h3>
    <form action="upload.jsp">
        <button>Upload</button>
    </form>
</div>

<div class="card">
    <h3>🧾 Complaint</h3>
    <form action="complaint.jsp">
        <button>Submit</button>
    </form>
    <form action="userInbox.jsp">
        <button>View Replies</button>
    </form>
</div>

<div class="card">
    <h3>☁ Cloud</h3>
    <form action="CloudDetailsServlet">
        <button>Open Cloud</button>
    </form>
</div>

<div class="card">
    <h3>🚪 Logout</h3>
    <form action="logout">
        <button class="logout">Logout</button>
    </form>
</div>

</div>

<!-- 🔐 FILE BUTTON LIST -->
<div class="file-box">

<h3>📂 Your Encrypted Files</h3>

<div style="text-align:center; margin:20px;">
    <a href="trash.jsp">
        <button style="background:#9c27b0;">🗑 Open Trash</button>
    </a>
</div>

<%
Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
    "SELECT id, filename, filedata_dna FROM files WHERE (receiver=? OR sender=?) AND deleted=0"
);

ps.setString(1, user);
ps.setString(2, user);

ResultSet rs = ps.executeQuery();

boolean hasFiles = false;

while(rs.next()) {
    hasFiles = true;
%>

<div style="margin-bottom:10px;">

    <!-- 🔐 DECRYPT BUTTON -->
    <form action="decrypt.jsp" method="get" style="display:inline;">
        <input type="hidden" name="id" value="<%= rs.getInt("id") %>">

        <button type="submit" class="file-btn">
            📥 Decrypt - <%= rs.getString("filename") %>
        </button>
    </form>

    <!-- 👁 VIEW ENCRYPTED BUTTON -->
    <a href="viewEncrypted.jsp?path=<%= rs.getString("filedata_dna") %>" 
       style="margin-left:10px; text-decoration:none;">
        <button type="button" class="file-btn" style="background:#ff9800;">
            👁 View Encrypted
        </button>
    </a>
    <!-- 🗑 DELETE BUTTON -->
<form action="DeleteFileServlet" method="post" style="display:inline;">
    <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
    
    <button type="submit"
        style="background:#f44336; margin-left:10px; padding:10px; border:none; border-radius:8px; color:white; cursor:pointer;"
        onclick="return confirm('Move to Trash?')">
        🗑 Delete
    </button>
</form>

</div>

<%
}  // ✅ while closed
%>

<%
if (!hasFiles) {
    out.println("<p>No files found.</p>");
}

con.close();
%>

</div>

</div>

</body>
<script>

// ✅ remove msg from URL (fix refresh issue)
if (window.history.replaceState) {
    const url = new URL(window.location);
    url.searchParams.delete("msg");
    window.history.replaceState({}, document.title, url);
}

// ✅ hide message
setTimeout(function() {
    var box = document.getElementById("msgBox");
    if (box) {
        box.style.display = "none";
    }
}, 3000);

</script>
</html>