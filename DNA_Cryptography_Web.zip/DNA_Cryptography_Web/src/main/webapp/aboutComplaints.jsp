<%@ page import="java.util.*"%>
<%@ page import="java.sql.*"%>
<%@ page import="dnaweb.DBConnection"%>
<%@ page contentType="text/html;charset=UTF-8"%>

<%
String user = (String) session.getAttribute("user");
String role = (String) session.getAttribute("role");

if (user == null || !"admin".equals(role)) {
	response.sendRedirect("index.jsp");
	return;
}
%>

<html>
<head>
<title>Admin Complaints</title>

<style>
body {
	font-family: 'Segoe UI';
	background: linear-gradient(to right, #eef2f3, #dfe9f3);
	margin: 0;
}

.header {
	background: #2c3e50;
	color: white;
	padding: 15px;
	text-align: center;
	font-size: 22px;
	font-weight: bold;
}

.container {
	width: 85%;
	margin: 20px auto;
}

.card {
	background: white;
	padding: 18px;
	margin-bottom: 15px;
	border-radius: 12px;
	box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.filename {
	font-weight: bold;
	font-size: 16px;
}

.meta {
	font-size: 13px;
	color: gray;
	margin-top: 5px;
}

textarea {
	width: 100%;
	padding: 8px;
	border-radius: 8px;
	border: 1px solid #ccc;
	margin-top: 8px;
}

input[type="file"] {
	margin-top: 8px;
}

button {
	margin-top: 10px;
	padding: 8px 12px;
	border: none;
	border-radius: 8px;
	background: #4CAF50;
	color: white;
	cursor: pointer;
}

button:hover {
	background: #45a049;
}

.success {
	background: #d4edda;
	color: #155724;
	padding: 10px;
	border-radius: 8px;
	margin: 10px;
	text-align: center;
}

.file {
	color: #2196F3;
	font-weight: bold;
}
</style>
</head>

<body>

	<div class="header">📢 Admin Complaint Management</div>

	<%
	String msg = request.getParameter("msg");

	if ("reply".equals(msg)) {
	%>
	<div id="successMsg" class="success">✅ Reply sent successfully!</div>
	<%
	}
	%>

	<div class="container">

		<%
		Connection con = DBConnection.getConnection();

		PreparedStatement ps = con.prepareStatement("SELECT * FROM complaints ORDER BY sent_time DESC");

		ResultSet rs = ps.executeQuery();

		boolean found = false;

		while (rs.next()) {
			found = true;

			String time = rs.getString("sent_time");
			if (time == null)
				time = "No Time";
		%>

		<div class="card">

			<div class="filename">
				👤
				<%=rs.getString("sender")%></div>

			<div class="meta">
				🕒
				<%=time%>
			</div>

			<br> <b>💬 Message:</b><br>
			<%=rs.getString("message")%><br>
			<br> <b>📎 File:</b> <span class="file"> <%=rs.getString("file_path") == null ? "No File" : rs.getString("file_path")%>
			</span>

			<!-- 🔁 REPLY FORM -->
			<form action="AdminReplyServlet" method="post"
				enctype="multipart/form-data">

				<input type="hidden" name="id" value="<%=rs.getInt("id")%>">

				<textarea name="reply_msg" placeholder="Type reply..."></textarea>

				<input type="file" name="file">

				<button type="submit">Send Reply</button>

			</form>

		</div>

		<%
		}

		if (!found) {
		%>
		<p style="text-align: center;">⚠ No complaints found</p>
		<%
		}

		con.close();
		%>

	</div>

	<script>

// ✅ remove msg from URL (so it won’t repeat on refresh)
if (window.history.replaceState) {
    const url = new URL(window.location);
    url.searchParams.delete("msg");
    window.history.replaceState({}, document.title, url);
}

// ✅ hide message after 3 sec
setTimeout(function() {
    var msg = document.getElementById("successMsg");
    if(msg){
        msg.style.opacity = "0";
        setTimeout(() => msg.style.display = "none", 500);
    }
}, 3000);

</script>

</body>
</html>