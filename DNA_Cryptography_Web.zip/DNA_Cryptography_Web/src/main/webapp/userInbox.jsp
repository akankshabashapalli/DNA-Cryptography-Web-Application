<%@ page import="java.sql.*" %>
<%@ page import="dnaweb.DBConnection" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<b style="color:#333;">📩 Admin Reply</b><br><br>

<%
String user = (String) session.getAttribute("user");

if(user == null){
    response.sendRedirect("index.jsp");
    return;
}

Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
    "SELECT * FROM complaints WHERE sender=? ORDER BY sent_time DESC"
);

ps.setString(1, user);

ResultSet rs = ps.executeQuery();

while(rs.next()){
%>

<div style="
    background:#ffffff;
    padding:15px;
    margin:15px;
    border-radius:12px;
    box-shadow:0 4px 10px rgba(0,0,0,0.1);
">

<b>📨 Your Complaint:</b><br>
💬 <%= rs.getString("message") %><br><br>



<b>👨‍💼 Admin Reply:</b><br>

<%
String replyMsg = rs.getString("reply_msg");
String replyFile = rs.getString("reply_file");

// ✅ SHOW MESSAGE
if(replyMsg != null && !replyMsg.trim().isEmpty()){
%>
    💬 <%= replyMsg %><br><br>
<%
}

// ✅ SHOW FILE
if(replyFile != null && !replyFile.trim().isEmpty()){

    String fileLower = replyFile.toLowerCase();
    String path = request.getContextPath() + "/" + replyFile;

    if(fileLower.endsWith(".jpg") || fileLower.endsWith(".png") || fileLower.endsWith(".jpeg")){
%>
        <img src="<%= path %>" width="200"/><br>
<%
    } else if(fileLower.endsWith(".mp3")){
%>
        <audio controls>
            <source src="<%= path %>">
        </audio><br>
<%
    } else if(fileLower.endsWith(".mp4")){
%>
        <video width="300" controls>
            <source src="<%= path %>">
        </video><br>
<%
    } else {
%>
        📄 <a href="<%= path %>" target="_blank">Download File</a><br>
<%
    }
}
%>

<br>
<b>🕒 Time:</b> <%= rs.getString("sent_time") %>

</div>

<%
}
%>