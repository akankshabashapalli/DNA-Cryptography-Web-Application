<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String user = (String) session.getAttribute("user");
    String role = (String) session.getAttribute("role");
    if (user == null || !"admin".equals(role)) {
        response.sendRedirect("index.jsp");
        return;
    }
%>
<html>
<head>
    <title>Files Time – Admin</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
        nav.menu { background: #34495e; padding: 10px; text-align: center; }
        nav.menu a { color: white; margin: 0 15px; text-decoration: none; }
        .container { margin: 20px auto; max-width: 800px; padding: 0 15px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<header>
    <h1>DNA Cryptography Cloud – Admin Dashboard</h1>
</header>

<nav class="menu">
    <a href="index.jsp">Home</a>
    <a href="adminDashboard.jsp">Dashboard</a>
    <a href="logout.jsp">Logout</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Files Time (Upload Time)</h2>
        <p>Displaying file upload timings is not yet implemented.</p>
    </div>
</div>

</body>
</html>