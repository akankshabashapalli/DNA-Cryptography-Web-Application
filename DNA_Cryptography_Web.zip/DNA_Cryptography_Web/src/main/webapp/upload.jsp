<html>
<head>
<title>Upload</title>
<style>
body {
    font-family: Arial;
    background: #f4f7fb;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}
form {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
input, button {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
}
button {
    background: #4CAF50;
    color: white;
    border: none;
}
</style>
</head>

<body>
<%
if("duplicate".equals(request.getParameter("msg"))) {
%>
<div style="background:#f44336;color:white;padding:10px;margin:10px;border-radius:8px;">
    ❌ File name already exists!
</div>
<%
}
%>

<form action="<%= request.getContextPath() %>/FileEncryptServlet"
      method="post"
      enctype="multipart/form-data">

    Receiver: <input type="text" name="receiver"><br><br>

    Key: <input type="text" name="key"><br><br>

    File: <input type="file" name="file"><br><br>

    <button type="submit">Send</button>

</form>

</body>
</html>