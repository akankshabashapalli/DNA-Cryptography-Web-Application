<%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head>
    <title>Decrypt File (DNA Cryptography)</title>
</head>
<body>

<h2>Decrypt Encrypted File (.enc.dna)</h2>

<form action="FileDecryptServlet" method="post" enctype="multipart/form-data">
    Select Encrypted File:
    <input type="file" name="file" required><br><br>

    Enter Key (same key used for encryption):
    <input type="text" name="key" required><br><br>

    <button type="submit">Decrypt</button>
</form>

</body>
</html>
