<html>
<body>

<h2>Decrypted Result:</h2>

<p>
<%= request.getAttribute("result") %>
</p>

<a href="index.jsp">Go Back</a>

</body>
</html>