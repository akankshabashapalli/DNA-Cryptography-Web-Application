<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*" %>
<%@ page import="dnaweb.FileRow" %>

<%
    String user = (String) session.getAttribute("user");
    String role = (String) session.getAttribute("role");
    if (user == null || !"admin".equals(role)) {
        response.sendRedirect("index.jsp");
        return;
    }

    @SuppressWarnings("unchecked")
    List<FileRow> files = (List<FileRow>) request.getAttribute("files");
    if (files == null) {
        files = new ArrayList<>();
    }
%>
<html>
<head>
    <title>Files Uploaded By – Admin</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
        nav.menu { background: #34495e; padding: 10px; text-align: center; }
        nav.menu a { color: white; margin: 0 15px; text-decoration: none; }
        .container { margin: 20px auto; max-width: 1000px; padding: 0 15px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px 10px; text-align: left; }
        th { background-color: #f0f0f9; }
    </style>
</head>
<body>

<header>
    <h1>DNA Cryptography Cloud – Files Uploaded By</h1>
</header>

<nav class="menu">
    <a href="index.jsp">Home</a>
    <a href="adminDashboard.jsp">Dashboard</a>
    <a href="logout.jsp">Logout</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Files Uploaded By</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Sender</th>
                <th>Receiver</th>
                <th>Filename</th>
                <th>Sent Time</th>
            </tr>

            <%
                if (files.isEmpty()) {
            %>
            <tr>
                <td colspan="5">No files found.</td>
            </tr>
            <%
                } else {
                    for (FileRow f : files) {
            %>
            <tr>
                <td><%= f.getId() %></td>
                <td><%= f.getSender() %></td>
                <td><%= f.getReceiver() %></td>
                <td><%= f.getFilename() %></td>
                <td><%= f.getSentTime() %></td>
            </tr>
            <%
                    }
                }
            %>
        </table>
    </div>
</div>

</body>
</html>