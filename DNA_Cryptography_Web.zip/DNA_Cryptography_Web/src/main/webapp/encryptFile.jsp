<html>
<head>
<style>
body { font-family:Segoe UI; background:#0f2027; color:white; text-align:center; }
.box { margin-top:100px; }
input,button { padding:10px; margin:10px; }
</style>
</head>

<body>

<div class="box">
<h2>Encrypt File</h2>

<form action="FileEncryptServlet" method="post" enctype="multipart/form-data">
<input type="file" name="file" required><br>
<input type="text" name="key" placeholder="Enter Key" required><br>
<input type="text" name="receiver" placeholder="Receiver" required><br>

<button type="submit">Encrypt & Send</button>
</form>

</div>

</body>
</html>