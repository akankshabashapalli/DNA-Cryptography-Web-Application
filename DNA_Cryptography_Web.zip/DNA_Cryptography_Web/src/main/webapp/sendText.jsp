<%@ page contentType="text/html;charset=UTF-8" %>

<%
String sender = (String) session.getAttribute("user");

if (sender == null) {
    response.sendRedirect("login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
    <title>Send Message</title>
</head>

<body style="font-family: Arial; background:#eef2f7;">

<div style="width:400px; margin:50px auto; padding:20px; background:white;
            border-radius:10px; box-shadow:0 0 10px #ccc;">

    <h2 style="text-align:center;">📨 Send Message</h2>

    <form action="SendMessageServlet" method="post">

        <!-- ✅ Hidden sender (SAFE) -->
        <input type="hidden" name="sender" value="<%= sender %>" />

        <label><b>To:</b></label><br>
        <input type="text" name="receiver" required
               style="width:100%; padding:8px;"><br><br>

        <label><b>Message:</b></label><br>
        <textarea name="message" required
                  style="width:100%; height:80px; padding:8px;"></textarea><br><br>

        <label><b>Key:</b></label><br>
        <input type="text" name="key" required
               style="width:100%; padding:8px;"><br><br>

        <button type="submit"
                style="width:100%; background:#4CAF50; color:white;
                       padding:10px; border:none; border-radius:5px;">
            Send
        </button>

    </form>

</div>

</body>
</html>