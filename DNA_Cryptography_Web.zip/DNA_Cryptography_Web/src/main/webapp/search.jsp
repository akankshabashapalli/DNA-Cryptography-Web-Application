<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*, dnaweb.UserDatabase" %>

<html>
<head>
    <title>Search Files</title>
</head>
<body>

<h2>Search Files</h2>

<form method="get">
    Enter keyword: <input type="text" name="keyword">
    <input type="submit" value="Search">
</form>

<br>

<table border="1">
<tr>
    <th>File Name</th>
</tr>

<%
String keyword = request.getParameter("keyword");
List<Map<String,String>> files = new ArrayList<>();

if(keyword != null && !keyword.trim().isEmpty()){
    files = UserDatabase.searchFiles(keyword);
}

for(Map<String,String> file : files){
%>

<tr>
    <td><%= file.get("filename") %></td>
</tr>

<%
}
%>

</table>

</body>
</html>