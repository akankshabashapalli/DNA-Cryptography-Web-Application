<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%
String user = (String) session.getAttribute("user");
%>

<div style="background:#e3f2fd; padding:10px; border-radius:8px; margin-bottom:15px;">
    👋 Welcome, <b><%= user != null ? user : "Guest" %></b>
</div>

<h2>📥 Your Messages</h2>

<%
List<Map<String,String>> msgs =
 (List<Map<String,String>>) request.getAttribute("messages");

String selectedDNA = (String) request.getAttribute("selectedDNA");
String decrypted = (String) request.getAttribute("decryptedMessage");

if (msgs != null && !msgs.isEmpty()) {

for (Map<String,String> m : msgs) {
%>

<div style="border:1px solid #ccc; padding:10px; margin:10px;">
    
    <b>From:</b> <%= m.get("sender") %><br>
    <b>Time:</b> <%= m.get("time") %><br><br>

    <form action="ReceiverDecryptServlet" method="post">

        <!-- ✅ CORRECT: send DNA value -->
        <input type="hidden" name="dna"
               value="<%= m.get("dna") == null ? "" : m.get("dna") %>"/>

        Key: <input type="text" name="key" required/>

        <button type="submit">Decrypt</button>
    </form>

    <!-- ✅ Show decrypted message ONLY for this box -->
    <%
    if (selectedDNA != null &&
        m.get("dna") != null &&
        selectedDNA.trim().equals(m.get("dna").trim())) {
    %>

        <p style="color:green;">
            🔓 Decrypted Message: <%= decrypted %>
        </p>

    <%
    }
    %>

</div>

<%
}
} else {
%>

<p>No messages found</p>

<%
}
%>