<%@ page import="java.io.*" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Encrypted DNA</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f7fb;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        textarea {
            width: 100%;
            height: 400px;
            font-family: monospace;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
        }

        .box {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>

<body>

<div class="box">

<%
String path = request.getParameter("path");

if (path == null || path.isEmpty()) {
%>
    <p>❌ File path missing</p>
<%
    return;
}

String fullPath = application.getRealPath("/") + path;

File file = new File(fullPath);

if (!file.exists()) {
%>
    <p>❌ File not found</p>
<%
    return;
}

// ✅ IMPORTANT: UTF-8 reader fix
BufferedReader br = new BufferedReader(
    new InputStreamReader(new FileInputStream(file), "UTF-8")
);

StringBuilder content = new StringBuilder();
String line;

while ((line = br.readLine()) != null) {
    content.append(line).append("\n");
}

br.close();
%>

<h2>🧬 Encrypted DNA Data</h2>

<textarea readonly>
<%= content.toString() %>
</textarea>

</div>

</body>
</html>