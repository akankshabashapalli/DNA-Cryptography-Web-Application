<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%

String user = (String) session.getAttribute("user");
String role = (String) session.getAttribute("role");

if (user == null || !"admin".equalsIgnoreCase(role)) {
    response.sendRedirect("index.jsp");
    return;
}
%>

<html>
<head>
<title>Admin Dashboard – DNA Cryptography</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f0f2f5;
}

header {
    background: #2c3e50;
    color: white;
    padding: 15px 0;
    text-align: center;
}

nav.menu {
    background: #34495e;
    padding: 10px;
    text-align: center;
}

nav.menu a {
    color: white;
    margin: 0 15px;
    text-decoration: none;
}

nav.menu a:hover {
    color: #f1c40f;
}

.container {
    margin: 20px auto;
    max-width: 800px;
    padding: 0 15px;
}

.card {
    background: #fff;
    border-radius: 10px;
    padding: 20px;
    margin: 15px 0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.btn-large {
    padding: 12px 20px;
    background: #2980b9;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1em;
    margin: 5px;
}

.btn-large:hover {
    background: #1c5980;
}
</style>
</head>

<body>

<header>
    <h1>DNA Cryptography Cloud – Admin Dashboard</h1>
</header>

<nav class="menu">
    <a href="index.jsp">Home</a>
    <a href="logout.jsp">Logout</a>
</nav>

<div class="container">

    <!-- ✅ FIXED NAME DISPLAY -->
    <div class="card">
        <h3>Welcome, <%= user %></h3>
        <p>Click one of the buttons below to manage system data.</p>
    </div>

    <div class="card">
        <h3>Admin Options</h3>

        <a href="adminAboutUsers">
            <button class="btn-large">About Users</button>
        </a><br><br>

        <a href="CloudDetailsServlet">
            <button class="btn-large">Files</button>
        </a><br><br>

        <a href="aboutComplaints.jsp">
            <button class="btn-large">Complaints</button>
        </a><br><br>

        <a href="CloudServlet">
    <button class="btn-large">☁ Cloud Storage</button>
</a><br><br>
    </div>

</div>

</body>
</html>