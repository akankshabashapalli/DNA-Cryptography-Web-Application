<%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head>
    <title>Encrypt Data</title>

    <style>
        body {
            font-family: Arial;
            background: #f4f4f4;
        }

        .box {
            width: 50%;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }

        button {
            padding: 10px;
            background: green;
            color: white;
            border: none;
            width: 100%;
        }

        button:hover {
            background: darkgreen;
        }

        a {
            text-decoration: none;
            color: blue;
        }
    </style>
</head>

<body>

<div class="box">

    <h2>Encrypt Data</h2>

    <form action="EncryptTextServlet" method="post">

        Enter Text:
        <textarea name="message" required></textarea>

        Enter Key:
        <input type="text" name="key" required>

        <button type="submit">Encrypt</button>

    </form>

    <br>
    <a href="index.jsp">⬅ Back to Home</a>

</div>

</body>
</html>