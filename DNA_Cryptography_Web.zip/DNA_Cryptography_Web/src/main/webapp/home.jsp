<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <h2>Welcome, <%= session.getAttribute("username") %>!</h2>
    <p>This is your dashboard.</p>

    <a href="EncryptServlet">Encrypt DNA</a><br>
    <a href="DecryptServlet">Decrypt DNA</a><br>
</body>
</html>