<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<html>
<head>
    <title>Set Ranking</title>

    <style>
        body {
            font-family: Arial;
            text-align: center;
        }

        form {
            margin-top: 50px;
        }

        input {
            padding: 10px;
            margin: 10px;
            width: 250px;
        }

        button {
            padding: 10px;
            background: green;
            color: white;
            border: none;
        }
    </style>
</head>

<body>

<h2>Set File Priority</h2>

<form action="RankingServlet" method="post">

    <input type="text" name="keyword" placeholder="Enter Keyword" required><br>

    <input type="number" name="priority" placeholder="Enter Priority" required><br>

    <button type="submit">Submit</button>

</form>

<br><br>

<a href="adminDashboard.jsp">Back to Dashboard</a>

</body>
</html>