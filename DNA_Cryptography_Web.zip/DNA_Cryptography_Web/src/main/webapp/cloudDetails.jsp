<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<html>
<head>
<title>Cloud Files</title>

<style>
body {
    font-family: 'Segoe UI';
    background: linear-gradient(to right, #eef2f3, #dfe9f3);
    margin: 0;
}

.header {
    background: #4CAF50;
    color: white;
    padding: 15px;
    font-size: 22px;
    text-align: center;
    font-weight: bold;
}

.container {
    width: 85%;
    margin: 30px auto;
}

.card {
    background: white;
    padding: 15px;
    margin-bottom: 15px;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.left {
    width: 60%;
}

.right {
    width: 35%;
}

.filename {
    font-weight: bold;
    font-size: 16px;
    color: #333;
}

.meta {
    font-size: 13px;
    color: gray;
    margin-top: 5px;
}

.sent {
    color: #4CAF50;
    font-weight: bold;
}

.received {
    color: #2196F3;
    font-weight: bold;
}

input {
    padding: 6px;
    border-radius: 6px;
    border: 1px solid #ccc;
    width: 60%;
}

button {
    padding: 6px 10px;
    border: none;
    border-radius: 6px;
    background: #4CAF50;
    color: white;
    cursor: pointer;
}

button:hover {
    background: #45a049;
}
</style>
</head>

<body>

<div class="header">
    ☁ My Cloud Files
</div>

<div class="container">

<%
String username = (String) session.getAttribute("user");

List<Map<String, String>> files =
    (List<Map<String, String>>) request.getAttribute("files");

if (files == null || files.size() == 0) {
%>

<p>⚠ No files found</p>

<%
} else {
    for (Map<String, String> file : files) {

        String sender = file.get("sender");
        String receiver = file.get("receiver");

        String type = "";
        String otherUser = "";
        String typeClass = "";

        if (sender.equals(username)) {
            type = "Sent";
            otherUser = receiver;
            typeClass = "sent";
        } else {
            type = "Received";
            otherUser = sender;
            typeClass = "received";
        }
%>

<div class="card">

    <!-- LEFT SIDE -->
    <div class="left">
        <div class="filename">📄 <%= file.get("filename") %></div>

        <div class="meta">
            Type: <span class="<%= typeClass %>"><%= type %></span> |
            Sender: <%= sender %> | Receiver: <%= receiver %> |
            Time: <%= file.get("sent_time") == null ? "No Time" : file.get("sent_time") %>
        </div>
    </div>

    <!-- RIGHT SIDE -->
    <div class="right">
        <form action="FileDecryptServlet" method="post">
<input type="hidden" name="id" value="<%= file.get("id") %>">
            <input type="hidden" name="dna" value="<%= file.get("dna") %>">
            <input type="hidden" name="filename" value="<%= file.get("filename") %>">

            <input type="text" name="key" placeholder="Enter key" required>

            <button type="submit">Decrypt</button>

        </form>
    </div>

</div>

<%
    }
}
%>

</div>

</body>
</html>