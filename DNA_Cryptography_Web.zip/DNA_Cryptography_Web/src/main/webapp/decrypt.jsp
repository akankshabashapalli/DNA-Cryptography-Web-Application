<%@ page import="java.sql.*" %>
<%@ page import="dnaweb.DBConnection" %>

<%
String id = request.getParameter("id");

if(id == null){
    out.println("<h3 style='color:red;'>❌ File ID missing</h3>");
    return;
}

Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
    "SELECT filename, filedata_dna FROM files WHERE id=?"
);
ps.setInt(1, Integer.parseInt(id));

ResultSet rs = ps.executeQuery();

String filename = "";
String dnaData = "";

if(rs.next()){
    filename = rs.getString("filename");
    dnaData = rs.getString("filedata_dna");
} else {
    out.println("❌ File not found");
    return;
}

con.close();
%>

<html>
<head>
<title>Decrypt File</title>
</head>

<body>

<h2>Decrypt: <%= filename %></h2>
<form action="FileDecryptServlet" method="post">

    <input type="hidden" name="id" value="<%= id %>">

    Enter Key:
    <input type="text" name="key" required>

    <button type="submit">Decrypt & Download</button>

</form>

</body>
</html>