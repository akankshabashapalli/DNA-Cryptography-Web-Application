<%@ page import="java.sql.*, dnaweb.*" %>

<html>
<head>
<style>
body { font-family:Segoe UI; background:#1e1e2f; color:white; }

.container { width:60%; margin:auto; }

.msg {
    background:#2c2c3c;
    padding:10px;
    margin:10px;
    border-radius:10px;
}

input,button {
    padding:10px;
    margin:5px;
}
</style>
</head>

<body>

<div class="container">

<h2>💬 Secure Chat</h2>

<form action="TextEncryptServlet" method="post">
<input type="text" name="receiver" placeholder="Receiver" required>
<input type="text" name="message" placeholder="Message" required>
<input type="text" name="key" placeholder="Key" required>
<button type="submit">Send</button>
</form>

<hr>

<h3>📥 Messages</h3>

<%
Connection con = DBConnection.getConnection();
PreparedStatement ps = con.prepareStatement("SELECT * FROM messages ORDER BY id DESC");
ResultSet rs = ps.executeQuery();

while(rs.next()){
%>

<div class="msg">
<b><%= rs.getString("sender") %></b> ➝ <b><%= rs.getString("receiver") %></b>

<form action="TextDecryptServlet" method="post">
<input type="hidden" name="dna" value="<%= rs.getString("message_dna") %>">
<input type="text" name="key" placeholder="Enter key">
<button>Decrypt</button>
</form>
</div>

<% } %>

</div>

</body>
</html>