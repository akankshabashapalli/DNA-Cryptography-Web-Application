<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, dnaweb.FileRow" %>

<%
String user = (String) session.getAttribute("user");
if (user == null) {
    response.sendRedirect("index.jsp");
    return;
}

List<FileRow> files = (List<FileRow>) request.getAttribute("files");
if (files == null) files = new ArrayList<>();
%>

<html>
<head>
<title>Received Files</title>
</head>

<body>

<h2>Received Files for: <%= user %></h2>

<table border="1">
<tr>
    <th>Filename</th>
    <th>Sender</th>
    <th>Time</th>
    <th>Action</th>
</tr>

<%
for(FileRow f : files){
%>

<tr>
    <td><%= f.getFilename() %></td>
    <td><%= f.getSender() %></td>
    <td><%= f.getSentTime() %></td>
    <td>
    <%= f.getFilename() %><br>

    <% if(f.getFilename().endsWith(".jpg") || f.getFilename().endsWith(".png")) { %>
        <small>🖼 Image File</small>
    <% } else if(f.getFilename().endsWith(".mp3")) { %>
        <small>🎵 Audio File</small>
    <% } else { %>
        <small>📄 Document</small>
    <% } %>
</td>
</tr>

<%
}
%>

</table>

</body>
</html>