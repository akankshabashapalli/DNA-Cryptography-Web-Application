<%@ page import="java.sql.*" %>
<%@ page import="dnaweb.DBConnection" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>

<html>
<head>
<meta charset="UTF-8">
<title>Trash</title>

<style>
body {
    font-family: Arial;
    background: #f4f7fb;
    margin: 0;
}

.container {
    width: 70%;
    margin: 30px auto;
}

h2 {
    text-align: center;
}

.card {
    background: white;
    padding: 15px;
    margin: 10px 0;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

button {
    padding: 8px 12px;
    margin-top: 8px;
    margin-right: 5px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.restore {
    background: #4CAF50;
    color: white;
}

.delete {
    background: #f44336;
    color: white;
}
</style>
</head>

<body>

<div class="container">

<h2>🗑 Trash</h2>

<%
Connection con = DBConnection.getConnection();

PreparedStatement ps = con.prepareStatement(
    "SELECT * FROM files WHERE deleted=1"
);

ResultSet rs = ps.executeQuery();

boolean found = false;

while(rs.next()) {
    found = true;
%>

<div class="card">

    <b>📄 File:</b> <%= rs.getString("filename") %> <br>

    <!-- RESTORE -->
    <form action="RestoreFileServlet" method="post" style="display:inline;">
        <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
        <button class="restore">♻ Restore</button>
    </form>

    <!-- DELETE FOREVER -->
    <form action="PermanentDeleteServlet" method="post" style="display:inline;">
        <input type="hidden" name="id" value="<%= rs.getInt("id") %>">
        <button class="delete"
            onclick="return confirm('Delete permanently?')">
            ❌ Delete Forever
        </button>
    </form>

</div>

<%
}

if(!found){
%>
<p style="text-align:center;">No files in Trash</p>
<%
}

con.close();
%>

</div>

</body>
</html>