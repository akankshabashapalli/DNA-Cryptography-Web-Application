<div style="background: #2c3e50; color: white; padding: 15px 0; text-align: center;">
    <h2>DNA Cryptography Cloud</h2>
</div>
<nav style="background: #34495e; padding: 10px; text-align: center;">
    <a href="index.jsp" style="color: white; margin: 0 15px; text-decoration: none;">
        Home
    </a>
    <a href="userDashboard.jsp" style="color: white; margin: 0 15px; text-decoration: none;">
        Dashboard
    </a>
    <a href="logout.jsp" style="color: white; margin: 0 15px; text-decoration: none;">
        Logout
    </a>
</nav>