<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>

<h2>Result</h2>

<p>
<%= request.getAttribute("result") %>
</p>

<a href="cloudservice.jsp">Back</a>

</body>
</html>