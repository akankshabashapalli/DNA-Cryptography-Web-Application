<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>

<h2>📥 Your Messages</h2>

<%
List<Map<String,String>> msgs =
 (List<Map<String,String>>) request.getAttribute("messages");

if (msgs != null && !msgs.isEmpty()) {

for (Map<String,String> m : msgs) {
%>

<div style="border:1px solid #ccc; padding:10px; margin:10px;">
    
    <b>From:</b> <%= m.get("sender") %><br>
    <b>Time:</b> <%= m.get("time") %><br>

    <form action="ReceiverDecryptServlet" method="post">

        <textarea name="message_text" style="display:none;">
            <%= m.get("message_text") == null ? "" : m.get("message_text").trim() %>
        </textarea>

        Key: <input type="text" name="key" required/>

        <button>Decrypt</button>

    </form>

</div>

<%
}
} else {
%>

<p>No messages found</p>

<%
}
%>

<!-- Show decrypted message -->
<%
String msg = (String) request.getAttribute("message");
if (msg != null) {
%>
    <h3>🔓 Decrypted Message:</h3>
    <p><%= msg %></p>
<%
}
%>