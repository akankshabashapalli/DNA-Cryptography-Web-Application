<%@ page import="java.sql.*" %>
<%@ page contentType="text/html; charset=UTF-8" %>

<html>
<head>
    <title>User Details</title>

    <style>
        body {
            font-family: Arial;
        }

        h2 {
            text-align: center;
        }

        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid black;
            text-align: center;
        }

        th {
            background-color: #2c3e50;
            color: white;
        }
    </style>
</head>

<body>

<h2>User Details</h2>

<table>
<tr>
    <th>ID</th>
    <th>Sender</th>
    <th>Receiver</th>
    <th>Type</th>
    <th>File Name</th>
</tr>

<%
try {
    Class.forName("com.mysql.cj.jdbc.Driver");

    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@");

    Statement st = con.createStatement();

    ResultSet rs = st.executeQuery("SELECT * FROM messages");

    while(rs.next()) {
%>

<tr>
    <td><%= rs.getInt("id") %></td>
    <td><%= rs.getString("sender") %></td>
    <td><%= rs.getString("receiver") %></td>
    <td><%= rs.getString("type") %></td>
    <td><%= rs.getString("file_name") %></td>
</tr>

<%
    }

    con.close();
} catch(Exception e) {
    out.println(e);
}
%>

</table>

<br><br>
<center>
    <a href="adminDashboard.jsp">Back to Dashboard</a>
</center>

</body>
</html>