<html>
<body style="text-align:center;font-family:Segoe UI">

<h2>Decrypt File</h2>

<form action="FileDecryptServlet" method="post" enctype="multipart/form-data">
<input type="file" name="file" required><br><br>
<input type="text" name="key" placeholder="Enter Key" required><br><br>

<button type="submit">Decrypt</button>
</form>

</body>
</html>