<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>

<h2>Login</h2>

<%
  String error = (String) request.getAttribute("error");
  if (error != null) {
%>
  <p style="color:red"><%= error %></p>
<%
  }
%>

<form action="${pageContext.request.contextPath}/LoginServlet" method="post">

    Username:<br>
    <input type="text" name="username" required><br><br>

    Password:<br>
    <input type="password" name="password" required><br><br>

    Role:<br>
    <select name="role" required>
        <option value="">Select role</option>
        <option value="user">User</option>
        <option value="owner">Owner</option>
        <option value="admin">Admin</option>
    </select><br><br>

    <button type="submit">Login</button>

</form>

</body>
</html>