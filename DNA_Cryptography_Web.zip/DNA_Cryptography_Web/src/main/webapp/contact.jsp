<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <title>Contact – DNA Cryptography Cloud</title>

    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            color: #333;
        }

        header {
            background: #2c3e50;
            color: white;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        header h1 {
            margin: 0;
        }

        nav.menu {
            background: #34495e;
            padding: 10px;
            text-align: center;
        }

        nav.menu a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: 500;
        }

        nav.menu a:hover {
            color: #f1c40f;
        }

        .container {
            max-width: 700px;
            margin: 30px auto;
            padding: 0 15px;
        }

        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        h2 {
            margin-top: 0;
            color: #2c3e50;
        }

        .info {
            margin: 10px 0;
            font-size: 16px;
        }

        .info strong {
            color: #2980b9;
        }

        .note {
            margin-top: 20px;
            font-size: 14px;
            color: #555;
        }

        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background: #2c3e50;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>

<body>

<header>
    <h1>📞 Contact – DNA Cryptography Cloud System</h1>
</header>

<nav class="menu">
    <a href="index.jsp">🏠 Home</a>
    <a href="register.jsp">📝 Register</a>
    <a href="contact.jsp">📞 Contact</a>
</nav>

<div class="container">
    <div class="card">
        <h2>Admin Contact Details</h2>

        <p class="info"><strong>Name:</strong> System Administrator</p>
        <p class="info"><strong>Email:</strong> admin@dnacrypto.com</p>
        <p class="info"><strong>Phone:</strong> +91 9876543210</p>
        <p class="info"><strong>Location:</strong> Hyderabad, India</p>

        <div class="note">
            For any issues related to account registration, login, encryption, or cloud access, 
            please contact the administrator.
        </div>

        <a href="index.jsp" class="btn">← Back to Home</a>
    </div>
</div>

</body>
</html>