<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<h2>☁ Cloud Stored Encrypted Files</h2>

<table border="1">
<tr>
    <th>Filename</th>
    <th>Storage</th>
    <th>Decrypt</th>
</tr>

<%
List<Map<String, String>> files =
    (List<Map<String, String>>) request.getAttribute("files");

if (files == null || files.size() == 0) {
%>

<tr>
    <td colspan="3">⚠ No files found</td>
</tr>

<%
} else {
    for (Map<String, String> file : files) {
%>

<tr>
    <td><%= file.get("filename") %></td>
    <td>☁ Cloud Server</td>

    <td>
        <form action="FileDecryptServlet" method="post">
            <input type="hidden" name="dna" value="<%= file.get("dna") %>">
            <input type="hidden" name="filename" value="<%= file.get("filename") %>">

            <input type="text" name="key" placeholder="Enter key" required>

            <button type="submit">Decrypt</button>
        </form>
    </td>
</tr>

<%
    }
}
%>

</table>