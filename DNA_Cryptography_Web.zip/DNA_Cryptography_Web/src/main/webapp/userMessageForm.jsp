<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<html>
<head>
    <title>Send Messages</title>
</head>
<body>

<h2>Send Text Message to Receiver</h2>
<form action="${pageContext.request.contextPath}/sendMessage" method="post">
    <input type="hidden" name="receiver" value="owner1">   <!-- or admin / other -->
    <label>To:</label>
    <input type="text" name="receiver" value="owner1" readonly><br><br>

    <label>Message (text only):</label><br>
    <textarea name="message" rows="4" cols="50" required></textarea><br><br>

    <button type="submit">Send Text Message</button>
</form>

<hr>

<h2>Send Document as Message</h2>
<form action="${pageContext.request.contextPath}/sendDocumentMessage" method="post"
      enctype="multipart/form-data">
    <label>To:</label>
    <input type="hidden" name="receiver" value="owner1">   <!-- or admin / other -->

    <input type="file" name="file" required><br><br>

    <button type="submit">Send Document as Message</button>
</form>

<br>
<a href="userDashboard.jsp">Back to Dashboard</a>

</body>
</html>