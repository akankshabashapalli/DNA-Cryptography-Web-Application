<%@ page import="java.sql.*" %>
<%@ page contentType="text/html; charset=UTF-8" %>

<html>
<head>
    <title>Download Details</title>
</head>
<body>

<h2 align="center">Download Details</h2>

<table border="1" align="center" cellpadding="10">
<tr>
    <th>ID</th>
    <th>Receiver</th>
    <th>File Name</th>
</tr>

<%
try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    Connection con = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@");

    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("SELECT * FROM messages");

    while(rs.next()) {
%>

<tr>
    <td><%= rs.getInt("id") %></td>
    <td><%= rs.getString("receiver") %></td>
    <td><%= rs.getString("file_name") %></td>
</tr>

<%
    }

    con.close();
} catch(Exception e) {
    out.println(e);
}
%>

</table>

<br><br>
<center><a href="adminDashboard.jsp">Back</a></center>

</body>
</html>