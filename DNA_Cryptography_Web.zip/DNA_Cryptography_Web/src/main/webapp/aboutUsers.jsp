<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.*" %>
<%@ page import="dnaweb.UserRow" %>

<%
    String user = (String) session.getAttribute("user");
    String role = (String) session.getAttribute("role");
    if (user == null || !"admin".equals(role)) {
        response.sendRedirect("index.jsp");
        return;
    }

    @SuppressWarnings("unchecked")
    List<UserRow> users = (List<UserRow>) request.getAttribute("users");
    if (users == null) {
        users = new ArrayList<>();
    }
%>
<html>
<head>
    <title>About Users – Admin</title>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
        .menu { background: #34495e; padding: 10px; text-align: center; }
        .menu a { color: white; margin: 0 15px; text-decoration: none; }
        .container { margin: 20px auto; max-width: 1000px; padding: 0 15px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px 10px; text-align: left; }
        th { background-color: #f0f0f9; }
    </style>
</head>
<body>

<header>
    <h1>DNA Cryptography Cloud – Admin Dashboard</h1>
</header>

<nav class="menu">
    <a href="index.jsp">Home</a>
    <a href="adminDashboard.jsp">Dashboard</a>
    <a href="logout.jsp">Logout</a>
</nav>

<div class="container">
    <div class="card">
        <h2>About Users</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
                <th>Role</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>DOB</th>
                <th>Gender</th>
                <th>Pincode</th>
            </tr>

            <%
                if (users.isEmpty()) {
            %>
            <tr>
                <td colspan="11">No users found.</td>
            </tr>
            <%
                } else {
                    for (UserRow u : users) {
            %>
            <tr>
                <td><%= u.getId() %></td>
                <td><%= u.getFname() %></td>
                <td><%= u.getLname() %></td>
                <td><%= u.getUsername() %></td>
                <td><%= u.getRole() %></td>
                <td><%= u.getEmail() %></td>
                <td><%= u.getPhone() %></td>
                <td><%= u.getAddress() %></td>
                <td><%= u.getDob() %></td>
                <td><%= u.getGender() %></td>
                <td><%= u.getPincode() %></td>
            </tr>
            <%
                    }
                }
            %>
        </table>
    </div>
</div>

</body>
</html>