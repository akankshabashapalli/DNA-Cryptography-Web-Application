<%@ page contentType="text/html; charset=UTF-8" %>
<%
String msg = request.getParameter("msg");
if ("failed".equals(msg)) {
%>
<div style="color:red; text-align:center; padding:10px; background:#fee; border-radius:5px; margin:20px 0;">
    ❌ Invalid Username or Password
</div>
<%
}
%>
<!DOCTYPE html>
<html>
<head>
    <title>DNA Cryptography Cloud System</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            color: #333;
        }
        header {
            background: #2c3e50;
            color: white;
            padding: 15px 0;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        header h1 { margin: 0; font-size: 1.8em; }
        nav.menu {
            background: #34495e;
            padding: 10px;
            text-align: center;
        }
        nav.menu a {
            color: white;
            margin: 0 15px;
            text-decoration: none;
            font-weight: 500;
        }
        nav.menu a:hover { color: #f1c40f; }
        .container {
            margin: 20px auto;
            max-width: 1100px;
            padding: 0 15px;
        }
        .row { display: flex; gap: 20px; }
        .col { flex: 1; }
        .card {
            background: white;
            border-radius: 10px;
            padding: 25px;
            margin: 15px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        button {
            padding: 12px 20px;
            background: #2980b9;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            font-weight: 500;
            margin: 8px 0;
        }
        button:hover { background: #1c5980; }
        input[type="text"], input[type="password"], select {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #2980b9;
            box-shadow: 0 0 0 2px rgba(41,128,185,0.2);
        }
        @media (max-width: 768px) { .row { flex-direction: column; } }
    </style>
</head>
<body>
<header>
    <h1>🧬 DNA Cryptography Cloud System</h1>
    <p>Secure Cloud Computing with Biological DNA Encryption</p>
</header>

<nav class="menu">
    <a href="index.jsp">🏠 Home</a>
    <a href="register.jsp">📝 Register</a>
    <a href="contact.jsp">📞 Contact</a>
</nav>

<div class="container">
    <div class="row">
        <div class="col">
            <img src="images/dna.jpg" alt="DNA Helix" 
                 style="width:100%; height:300px; border-radius:12px; object-fit:cover;">
            <div class="card">
                <h2>🔬 DNA Cryptography Technology</h2>
                <p style="line-height:1.7; font-size:16px;">
                    Revolutionary <strong>DNA-based encryption</strong> converts binary data to 
                    DNA sequences (A, C, G, T) using 2-bit encoding per nucleotide.
                </p>
            </div>
        </div>

        <div class="col">
            <div class="card">
                <h3>🔐 Secure Login</h3>
                <form action="LoginServlet" method="post">
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <select name="role" required>
                        <option value="">Select Role</option>
                        <option value="admin">👨‍💼 Admin</option>
                        <option value="user">👤 User</option>
                        <option value="owner">💼 Data Owner</option>
                    </select>
                    <button type="submit">Login → Dashboard</button>
                </form>
                <hr style="margin:20px 0;">
                <p style="text-align:center; margin:0; font-size:14px;">
                    New user? <a href="register.jsp" style="color:#2980b9; font-weight:500;">Create Account</a>
                </p>
            </div>
        </div>
    </div>
</div>
</body>
</html>