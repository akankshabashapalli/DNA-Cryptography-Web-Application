<!DOCTYPE html>
<html>
<head>
    <title>Upload File</title>
</head>
<body>

<h2>Upload File</h2>

<form action="UploadServlet" method="post" enctype="multipart/form-data">

    Select File:<br>
    <input type="file" name="file" required><br><br>

    Enter Key (min 4 characters):<br>
    <input type="text" name="key" placeholder="e.g. A@7b" required><br><br>

    <button type="submit">Upload</button>

</form>

</body>
</html>