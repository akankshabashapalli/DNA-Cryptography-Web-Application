<%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head>
    <title>Encrypt Any File (DNA Cryptography)</title>
</head>
<body>

<h2>Encrypt File (Image / Audio / Document / Message)</h2>

<form action="FileEncryptServlet" method="post" enctype="multipart/form-data">
    Select File:
    <input type="file" name="file" required><br><br>

    Enter Key (any letters, digits, symbols):
    <input type="text" name="key" required><br><br>

    <button type="submit">Encrypt</button>
</form>

</body>
</html>
