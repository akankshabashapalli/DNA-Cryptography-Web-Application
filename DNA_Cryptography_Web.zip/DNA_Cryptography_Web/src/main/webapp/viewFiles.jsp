<%@ page import="java.util.*" %>
<html>
<head>
<title>Files</title>

<style>
body {
    font-family: Arial;
    background: #f4f7fb;
    padding: 30px;
}

h2 {
    text-align: center;
}

table {
    width: 80%;
    margin: auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

th, td {
    padding: 12px;
    border: 1px solid #ddd;
    text-align: center;
}

th {
    background: #4CAF50;
    color: white;
}

button {
    padding: 6px 12px;
    border: none;
    background: #2196F3;
    color: white;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background: #0b7dda;
}
</style>

</head>

<body>

<h2>📁 Uploaded Files</h2>

<table>
<tr>
    <th>ID</th>
    <th>Filename</th>
    <th>Action</th>
</tr>

<%
List<Map<String,String>> files =
    (List<Map<String,String>>) request.getAttribute("files");

if (files != null && !files.isEmpty()) {
    for (Map<String,String> f : files) {
%>

<tr>
    <td><%= f.get("id") %></td>
    <td><%= f.get("filename") %></td>
    <td>
        <form action="decryptFile.jsp" method="post">
            <input type="hidden" name="dna"
                   value="<%= f.get("dna") %>"/>
            <button type="submit">Decrypt</button>
        </form>
    </td>
</tr>

<%
    }
} else {
%>

<tr>
    <td colspan="3">No Files Found</td>
</tr>

<%
}
%>

</table>

</body>
</html>