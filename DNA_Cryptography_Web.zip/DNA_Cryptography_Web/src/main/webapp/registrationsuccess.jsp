<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Registration Success</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<header>
    <h1>Registration Successful!</h1>
</header>

<nav>
    <ul>
        <li><a href="index.jsp">Home</a></li>
        <li><a href="registration.jsp">Registration</a></li>
        <li><a href="search.jsp">Search</a></li>
        <li><a href="contact.jsp">Contact Us</a></li>
    </ul>
</nav>

<main>
    <h2>Welcome, ${name}!</h2>
    <p>Your account with email <strong>${email}</strong> has been created successfully.</p>
    <p>You can now use the Encrypt and Decrypt services.</p>
</main>

</body>
</html>