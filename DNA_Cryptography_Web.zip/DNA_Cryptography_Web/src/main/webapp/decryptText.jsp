<%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head>
    <title>Decrypt Text Message – DNA Cryptography</title>
    <style>
        body { margin: 0; font-family: 'Segoe UI'; background: #f0f2f5; }
        header { background: #2c3e50; color: white; padding: 15px 0; text-align: center; }
        .container { margin: 20px auto; max-width: 800px; padding: 0 15px; }
        .card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        button { padding: 8px 14px; background: #2980b9; color: white; border: none; border-radius: 6px; }
        input[type="file"], input[type="text"] {
            width: 97%; padding: 10px 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 6px;
        }
    </style>
</head>
<body>
<header>
    <h1>DNA Cryptography Cloud – Decrypt Text</h1>
</header>

<div class="container">
    <div class="card">
        <h2>Decrypt .enc.dna Text Message</h2>

        <!-- User / Owner uploads the .enc.dna text file -->
        <form action="TextDecryptServlet" method="post">
            <input type="file" name="dnaFile" accept=".txt,.enc.dna" required><br>
            <input type="text" name="key" placeholder="Enter Key (digits only)" required><br><br>
            <button type="submit">Decrypt Text</button>
        </form>

        <p>
            This decrypts your DNA‑encrypted text message back to plain text.
        </p>

        <br>
        <a href="userDashboard.jsp">← Back to Dashboard</a>
    </div>
</div>
</body>
</html>