<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>

<%
String role = (String) session.getAttribute("role");
if (role == null || !role.equals("admin")) {
    response.sendRedirect("index.jsp");
    return;
}

List<Map<String, String>> files =
    (List<Map<String, String>>) request.getAttribute("files");
%>

<h2>☁ Cloud Storage (Admin)</h2>

<%
if (files == null || files.size() == 0) {
%>
<p>No files found</p>
<%
} else {
    for (Map<String, String> file : files) {
%>

<div style="background:white; padding:15px; margin:10px; border-radius:10px;">
    <b>📄 File Name:</b> <%= file.get("filename") %> <br>
    <b>👤 Sender:</b> <%= file.get("sender") %> <br>
    <b>📥 Receiver:</b> <%= file.get("receiver") %> <br>
    <b>🕒 Time:</b> <%= file.get("sent_time") %> <br>
</div>

<%
    }
}
%>