<%@ page contentType="text/html; charset=UTF-8" %>
<%
    request.getRequestDispatcher("/logout").forward(request, response);
%>