<%@ page import="java.util.*" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
String user = (String) session.getAttribute("user");
if (user == null) {
    response.sendRedirect("index.jsp");
    return;
}

List<Map<String,String>> messages =
    (List<Map<String,String>>) request.getAttribute("messages");
%>

<html>
<head>
<title>Data Owner Inbox</title>

<style>
body {
    margin: 0;
    font-family: 'Segoe UI';
    background: #f4f7fb;
}

.header {
    background: white;
    padding: 15px 30px;
    font-size: 20px;
    font-weight: bold;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

.container {
    padding: 30px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
}

th, td {
    padding: 12px;
    text-align: center;
}

th {
    background: #4CAF50;
    color: white;
}

tr:nth-child(even) {
    background: #f9f9f9;
}

button {
    padding: 6px 12px;
    border: none;
    border-radius: 6px;
    background: #4CAF50;
    color: white;
    cursor: pointer;
}

button:hover {
    background: #45a049;
}
</style>

</head>

<body>

<div class="header">
    📥 Data Owner Inbox
</div>

<div class="container">

<table>
<tr>
    <th>Sender</th>
    <th>Message</th>
    <th>Decrypt</th>
</tr>

<%
if (messages == null || messages.size() == 0) {
%>
<tr>
    <td colspan="3">No Messages Found</td>
</tr>
<%
} else {
    for (Map<String,String> msg : messages) {
%>

<tr>
    <td><%= msg.get("sender") %></td>
    <td><%= msg.get("dna") %></td>

    <td>
        <form action="DecryptServlet" method="post">
            <input type="hidden" name="data" value="<%= msg.get("dna") %>">
            <input type="hidden" name="key" value="<%= msg.get("key") %>">

            <input type="text" name="userkey" placeholder="Enter key" required>

            <button>Decrypt</button>
        </form>
    </td>
</tr>

<%
    }
}
%>

</table>

</div>

</body>
</html>