<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    String user = (String) session.getAttribute("user");
    if (user == null) {
        response.sendRedirect("index.jsp");
        return;
    }
%>
<html>
<head>
    <title>Send Document – DNA Cryptography</title>
    <%@ include file="header.jsp" %>
    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f0f2f5; }
        .container { margin: 20px auto; max-width: 600px; }
        .card { background: #fff; border-radius: 10px; padding: 20px; margin: 15px 0; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        label { display: block; margin: 8px 0 4px 0; }
        input { width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { padding: 10px 15px; background: #2980b9; color: white; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h2>Send Document</h2>

        <form action="FileEncryptServlet" method="post" enctype="multipart/form-data">
            <label>Document:</label>
            <input type="file" name="file" required>

            <label>Key:</label>
            <input type="text" name="key" required>

            <label>Receiver:</label>
            <input type="text" name="receiver" required>

            <button type="submit">Encrypt & Send</button>
        </form>
    </div>
</div>

</body>
</html>