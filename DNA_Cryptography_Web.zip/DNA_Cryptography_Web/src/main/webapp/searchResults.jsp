<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.Map" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Search Results - DNA Cryptography</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>

<header>
    <h1>Search Results</h1>
</header>

<main>
<%
    // Get the users map passed from servlet
    Map<String, String[]> users = (Map<String, String[]>) request.getAttribute("users");

    if(users == null || users.isEmpty()) {
%>
        <p>No users found. Please register first.</p>
<%
    } else {
%>
        <table border="1" cellpadding="5" A="0">
            <tr>
                <th>Username</th>
                <th>Role</th>
            </tr>
<%
        for(Map.Entry<String,String[]> entry : users.entrySet()) {
            String username = entry.getKey();
            String role = entry.getValue()[0]; // assuming role is at index 0
%>
            <tr>
                <td><%= username %></td>
                <td><%= role %></td>
            </tr>
<%
        }
%>
        </table>
<%
    }
%>

<br>
<a href="search.jsp">Back to Search</a>
</main>

</body>
</html>