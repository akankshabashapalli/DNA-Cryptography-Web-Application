package dnaweb;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/DecryptTextServlet")
public class DecryptTextServlet extends HttpServlet {

    private static final String CHARSET =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?/ ";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        process(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        process(request, response);
    }

    private void process(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String cipher = request.getParameter("cipher");
        String keyInput = request.getParameter("key");

        if (cipher == null || keyInput == null || keyInput.isEmpty()) {
            out.println("Enter cipher and key.");
            return;
        }

        int[] key = new int[keyInput.length()];
        for (int i = 0; i < keyInput.length(); i++) {
            key[i] = keyInput.charAt(i);
        }

        StringBuilder decrypted = new StringBuilder();

        for (int i = 0; i < cipher.length(); i++) {
            char ch = cipher.charAt(i);
            int index = CHARSET.indexOf(ch);

            if (index == -1) {
                decrypted.append(ch);
                continue;
            }

            int k = key[i % key.length];
            int originalIndex = (index - k + CHARSET.length()) % CHARSET.length();

            decrypted.append(CHARSET.charAt(originalIndex));
        }

        out.println("<h2>Decrypted Text:</h2>");
        out.println("<textarea rows='5' cols='50'>" + decrypted + "</textarea>");
    }
}