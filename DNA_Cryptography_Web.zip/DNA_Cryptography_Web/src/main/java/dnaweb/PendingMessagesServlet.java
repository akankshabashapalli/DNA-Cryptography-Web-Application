package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/pendingMessages")
public class PendingMessagesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendError(403, "Access denied.");
            return;
        }

        String receiver = (String) session.getAttribute("user");

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        out.print("[");
        boolean first = true;

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, sender, message_text, created_at " +
                "FROM messages " +
                "WHERE receiver = ? AND status = 'sent' " +
                "ORDER BY id DESC"
            );
            ps.setString(1, receiver);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!first) out.print(",");
                first = false;

                int id       = rs.getInt("id");
                String sender  = rs.getString("sender");
                String message = rs.getString("message_text");
                String time    = rs.getString("created_at");

                message = message.replace("\"", "\\\"");

                out.printf(
                    "{"
                    + "\"id\":%d,"
                    + "\"sender\":\"%s\","
                    + "\"message\":\"%s\","
                    + "\"time\":\"%s\""
                    + "}",
                    id, sender, message, time
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("]");
    }
}