package dnaweb;
import java.io.IOException;
import java.sql.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/ViewComplaintsServlet")
public class ViewComplaintsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, String>> list = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@");

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM complaints WHERE LOWER(receiver) = 'admin'"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> map = new HashMap<>();

                map.put("sender", rs.getString("sender"));
                map.put("receiver", rs.getString("receiver"));
                map.put("message", rs.getString("message"));
                map.put("file_path", rs.getString("file_path"));
                map.put("sent_time", rs.getString("sent_time"));

                list.add(map);
            }

            request.setAttribute("complaints", list);

            RequestDispatcher rd = request.getRequestDispatcher("aboutComplaints.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}