package dnaweb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/TestConnectionServlet")
public class TestConnectionServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();

            if (conn != null) {
                out.println("<h3>✅ Database Connected Successfully!</h3>");
            } else {
                out.println("<h3>❌ Database Connection Failed!</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3>❌ Error: " + e.getMessage() + "</h3>");
        }
    }
}