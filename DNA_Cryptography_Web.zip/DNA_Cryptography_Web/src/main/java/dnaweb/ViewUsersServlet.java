package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ViewUsersServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement("SELECT * FROM users");

            ResultSet rs = ps.executeQuery();

            PrintWriter out = response.getWriter();

            out.println("<h2>User Details</h2>");

            while (rs.next()) {
                out.println(rs.getString("fname") + " | " +
                            rs.getString("username") + "<br>");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}