package dnaweb;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CloudDetailsServlet")
public class CloudDetailsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, String>> files = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            // ✅ GET USER + ROLE (ONLY ONCE)
            String username = (String) request.getSession().getAttribute("user");
            String role = (String) request.getSession().getAttribute("role");

            PreparedStatement ps;

            if ("admin".equals(role)) {

                // ✅ ADMIN → ALL FILES
                ps = con.prepareStatement("SELECT * FROM files WHERE deleted=0 ORDER BY id DESC");

            } else {

                // 👤 USER → ONLY THEIR FILES
                ps = con.prepareStatement(
                    "SELECT * FROM files WHERE deleted=0 AND (sender = ? OR receiver = ?) ORDER BY id DESC"
                );
                ps.setString(1, username);
                ps.setString(2, username);
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Map<String, String> file = new HashMap<>();

                file.put("id", rs.getString("id"));
                file.put("sender", rs.getString("sender"));
                file.put("receiver", rs.getString("receiver"));
                file.put("filename", rs.getString("filename"));
                file.put("sent_time", rs.getTimestamp("sent_time") + "");
                file.put("dna", rs.getString("filedata_dna")); // keep for decrypt

                files.add(file);
            }

            request.setAttribute("files", files);

            // ✅ CLEAN FORWARD (NO DUPLICATE VARIABLE)
            RequestDispatcher rd;

            if ("admin".equals(role)) {
                rd = request.getRequestDispatcher("adminCloud.jsp");
            } else {
                rd = request.getRequestDispatcher("cloudDetails.jsp");
            }

            rd.forward(request, response);

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}