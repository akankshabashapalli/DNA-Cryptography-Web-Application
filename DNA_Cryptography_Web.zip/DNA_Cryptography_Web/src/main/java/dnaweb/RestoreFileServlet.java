package dnaweb;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/RestoreFileServlet")
public class RestoreFileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "UPDATE files SET deleted=0 WHERE id=?"
            );

            ps.setInt(1, id);
            ps.executeUpdate();

            con.close();

            response.sendRedirect("trash.jsp?msg=restored");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}