package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String username = req.getParameter("username").trim();
        String password = req.getParameter("password").trim();
        String role = req.getParameter("role").trim();

        System.out.println("Login attempt - Username: " + username + ", Role: " + role);

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM users WHERE username = ? AND password = ? AND role = ?"
            );
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                HttpSession session = req.getSession();
                // ✅ FIXED: Use "user" instead of "username" to match JSPs
                session.setAttribute("user", username);      // ← CHANGED
                session.setAttribute("role", role);
                
                System.out.println("Login SUCCESS for: " + username + " → " + role + " dashboard");
                
                if ("admin".equals(role)) {
                    res.sendRedirect("adminDashboard.jsp");
                } else if ("owner".equals(role)) {
                    res.sendRedirect("ownerDashboard.jsp");
                } else {
                    res.sendRedirect("userDashboard.jsp");    // Note: yours is just "Dashboard" 
                }
            } else {
                System.out.println("Login FAILED for: " + username);
                res.sendRedirect("index.jsp?msg=failed");
            }

            rs.close(); ps.close(); con.close();
        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("index.jsp?msg=failed");
        }
    }
}