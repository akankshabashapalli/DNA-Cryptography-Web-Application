package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import java.util.*;

@WebServlet("/DataOwnerInboxServlet")
public class DataOwnerInboxServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        List<Map<String,String>> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM messages WHERE receiver='dataowner' ORDER BY id DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String,String> msg = new HashMap<>();

                msg.put("sender", rs.getString("sender"));
                msg.put("dna", rs.getString("message_text"));
                msg.put("key", rs.getString("secret_key"));

                list.add(msg);
            }

            req.setAttribute("messages", list);
            req.getRequestDispatcher("dataowner_inbox.jsp")
               .forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().write("Error: " + e.getMessage());
        }
    }
}