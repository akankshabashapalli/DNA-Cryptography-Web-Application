package dnaweb;

public class UserRow {

    private int id;
    private String fname;
    private String lname;
    private String username;
    private String role;
    private String email;
    private String phone;
    private String address;
    private String dob;
    private String gender;
    private String pincode;

    public UserRow(int id, String fname, String lname, String username,
                   String role, String email, String phone,
                   String address, String dob, String gender,
                   String pincode) {
        this.id = id;
        this.fname = fname;
        this.lname = lname;
        this.username = username;
        this.role = role;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.dob = dob;
        this.gender = gender;
        this.pincode = pincode;
    }

    public int getId()           { return id; }
    public String getFname()     { return fname; }
    public String getLname()     { return lname; }
    public String getUsername()  { return username; }
    public String getRole()      { return role; }
    public String getEmail()     { return email; }
    public String getPhone()     { return phone; }
    public String getAddress()   { return address; }
    public String getDob()       { return dob; }
    public String getGender()    { return gender; }
    public String getPincode()   { return pincode; }
}