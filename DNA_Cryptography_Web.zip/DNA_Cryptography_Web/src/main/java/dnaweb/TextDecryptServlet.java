package dnaweb;

import java.io.*;
import java.nio.charset.StandardCharsets;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class TextDecryptServlet extends HttpServlet {

    // DNA → bytes (same as in FileDecryptServlet)
    private byte[] dnaToBytes(String dna) {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        int value = 0;
        int shift = 0;

        for (char c : dna.toCharArray()) {
            int bits;
            if (c == 'A') bits = 0;
            else if (c == 'C') bits = 1;
            else if (c == 'G') bits = 2;
            else if (c == 'T') bits = 3;
            else bits = 0;

            value |= (bits << shift);
            shift += 2;

            if (shift == 8) {
                out.write(value);
                value = 0;
                shift = 0;
            }
        }
        return out.toByteArray();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String dnaSequence = request.getParameter("dna");
        String keyStr = request.getParameter("key");

        if (dnaSequence == null || keyStr == null || keyStr.isEmpty()) {
            response.sendError(400, "DNA or key missing.");
            return;
        }

        int[] key = new int[keyStr.length()];
        for (int i = 0; i < keyStr.length(); i++) {
            if (!Character.isDigit(keyStr.charAt(i))) {
                response.sendError(400, "Key must be digits only.");
                return;
            }
            key[i] = Character.getNumericValue(keyStr.charAt(i));
        }

        byte[] encryptedData = dnaToBytes(dnaSequence);

        java.io.ByteArrayOutputStream decOutput = new java.io.ByteArrayOutputStream();
        for (int i = 0; i < encryptedData.length; i++) {
            int value = encryptedData[i] ^ 170;                  // reverse XOR‑170
            int k = key[i % key.length];
            int original = (value - k + 256) % 256;              // reverse key
            decOutput.write(original);
        }

        String decryptedText = new String(decOutput.toByteArray(), StandardCharsets.UTF_8);
        String contentType = "text/plain";
        String filename = "decrypted_message.txt";

        response.setContentType(contentType);
        response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\"");
        response.getWriter().write(decryptedText);
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }
}