package dnaweb;

public class FileRow {

    private int id;
    private String sender;
    private String receiver;
    private String filename;
    private String fileDataDna;
    private String sentTime;

    // ✅ FULL CONSTRUCTOR (MATCHES YOUR SERVLETS)
    public FileRow(int id, String sender, String receiver, String filename, String fileDataDna, String sentTime) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.filename = filename;
        this.fileDataDna = fileDataDna;
        this.sentTime = sentTime;
    }

    // ✅ GETTERS
    public int getId() { return id; }
    public String getSender() { return sender; }
    public String getReceiver() { return receiver; }
    public String getFilename() { return filename; }
    public String getFileDataDna() { return fileDataDna; }
    public String getSentTime() { return sentTime; }
}