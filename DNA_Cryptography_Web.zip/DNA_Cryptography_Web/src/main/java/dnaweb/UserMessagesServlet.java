package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/user/messages")
public class UserMessagesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendError(403, "Access denied.");
            return;
        }

        String receiver = (String) session.getAttribute("user");   // owner receives

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        out.print("[");
        boolean first = true;

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT sender, message_text, created_at " +
                "FROM messages " +
                "WHERE receiver = ? " +
                "ORDER BY id DESC"
            );
            ps.setString(1, receiver);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!first) out.print(",");
                first = false;

                String sender   = rs.getString("sender");
                String message  = rs.getString("message_text");
                String time     = rs.getString("created_at");

                message = message.replace("\"", "\\\"");

                out.printf(
                    "{\"sender\":\"%s\",\"message\":\"%s\",\"time\":\"%s\"}",
                    sender, message, time
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("]");
    }
}