package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        res.setContentType("text/html");

        PrintWriter out = res.getWriter();

        try {
            // GET FORM DATA
        	String fname = req.getParameter("fname");
        	String lname = req.getParameter("lname");
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            String confirmPassword = req.getParameter("confirmPassword");
            if (!password.equals(confirmPassword)) {
                res.sendRedirect("register.jsp?msg=error");
                return;
            }
            String role = req.getParameter("role");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");
            String dob = req.getParameter("dob");
            String gender = req.getParameter("gender");
            String pincode = req.getParameter("pincode");
            Class.forName("com.mysql.cj.jdbc.Driver");

            // DB CONNECTION
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project",
                "root",
                "@*akank321*@"
            );

            // INSERT QUERY
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO users (fname, lname, username, password, role, email, phone, address, dob, gender, pincode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            ps.setString(1, fname);
            ps.setString(2, lname);
            ps.setString(3, username);
            ps.setString(4, password);
            ps.setString(5, role);
            ps.setString(6, email);
            ps.setString(7, phone);
            ps.setString(8, address);
            ps.setString(9, dob);
            ps.setString(10, gender);
            ps.setString(11, pincode);

            int i = ps.executeUpdate();

            if (i > 0) {
            	res.sendRedirect("register.jsp?msg=success");
            } else {
                out.println("Registration failed");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }
    }
}