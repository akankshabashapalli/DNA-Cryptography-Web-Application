package dnaweb;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESUtil {

    private static byte[] fixKey(String key) {
        byte[] k = new byte[16];
        byte[] kb = key.getBytes();

        for (int i = 0; i < 16; i++) {
            k[i] = (i < kb.length) ? kb[i] : 0;
        }
        return k;
    }

    public static byte[] encrypt(byte[] data, String key) throws Exception {
        SecretKeySpec sk = new SecretKeySpec(fixKey(key), "AES");
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.ENCRYPT_MODE, sk);
        return c.doFinal(data);
    }

    public static byte[] decrypt(byte[] data, String key) throws Exception {
        SecretKeySpec sk = new SecretKeySpec(fixKey(key), "AES");
        Cipher c = Cipher.getInstance("AES");
        c.init(Cipher.DECRYPT_MODE, sk);
        return c.doFinal(data);
    }
}