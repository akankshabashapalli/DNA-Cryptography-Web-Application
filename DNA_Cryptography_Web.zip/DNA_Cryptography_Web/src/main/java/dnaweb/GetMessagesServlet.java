package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/GetMessagesServlet")
public class GetMessagesServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String user = (String) session.getAttribute("user");

        List<Message> messageList = new ArrayList<>();

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project?useSSL=false&serverTimezone=UTC",
                "root", "@*akank321*@"
            );

            String sql = "SELECT sender, message_text, status, created_at FROM messages WHERE receiver=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, user);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                messageList.add(new Message(
                        rs.getString("sender"),
                        rs.getString("message_text"),
                        rs.getString("status"),
                        rs.getString("created_at")
                ));
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("messages", messageList);

        RequestDispatcher rd = request.getRequestDispatcher("receivedMessages.jsp");
        rd.forward(request, response);
    }
}