package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import java.util.*;

@WebServlet("/FileFetchServlet")
public class FileFetchServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        List<Map<String, String>> fileList = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            String user = (String) req.getSession().getAttribute("user");

            PreparedStatement ps = con.prepareStatement(
            	    "SELECT * FROM files WHERE deleted=0 ORDER BY id DESC"
            	);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> file = new HashMap<>();

                file.put("id", rs.getString("id"));
                file.put("filename", rs.getString("filename"));
                file.put("dna",
                rs.getString("filedata_dna"));

                fileList.add(file);
            }

            req.setAttribute("files", fileList);

            RequestDispatcher rd = req.getRequestDispatcher("cloudDetails.jsp");
            rd.forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().write("Error: " + e.getMessage());
        }
    }
}