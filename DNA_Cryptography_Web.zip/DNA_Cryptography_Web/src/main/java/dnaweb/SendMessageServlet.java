package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import java.nio.charset.StandardCharsets;

@WebServlet("/SendMessageServlet")
public class SendMessageServlet extends HttpServlet {

    private String textToDNA(String text, String keyStr) {

        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        byte[] key = keyStr.getBytes(StandardCharsets.UTF_8);

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        for (int i = 0; i < bytes.length; i++) {

            int val = bytes[i] & 0xFF;

            val = val ^ 170;
            val = val ^ key[i % key.length];
            val = ((val << 3) | (val >> 5)) & 0xFF;

            for (int j = 3; j >= 0; j--) {
                int bits = (val >> (j * 2)) & 3;

                switch (bits) {
                    case 0: out.write('A'); break;
                    case 1: out.write('C'); break;
                    case 2: out.write('G'); break;
                    case 3: out.write('T'); break;
                }
            }
        }

        String dna = out.toString();

        // mutate
        StringBuilder mutated = new StringBuilder();
        for (char c : dna.toCharArray()) {
            switch (c) {
                case 'A': mutated.append('T'); break;
                case 'T': mutated.append('A'); break;
                case 'C': mutated.append('G'); break;
                case 'G': mutated.append('C'); break;
            }
        }

        return mutated.reverse().toString();
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String sender = (String) req.getSession().getAttribute("user");
        String receiver = req.getParameter("receiver");
        String message = req.getParameter("message");
        String key = req.getParameter("key");

        if (sender == null || receiver == null || message == null || key == null ||
            receiver.isEmpty() || message.isEmpty() || key.isEmpty()) {

            res.getWriter().write("❌ Missing Data!");
            return;
        }

        try {
            String dna = textToDNA(message, key);

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO messages(sender, receiver, message_text, created_at) VALUES (?, ?, ?, NOW())"
            );

            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, dna);

            ps.executeUpdate();

            res.sendRedirect("userDashboard.jsp?msg=success");

        }catch (Exception e) {
        	res.sendRedirect("userDashboard.jsp?msg=error"); 
        }
    }
}
