package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class SearchServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String search = request.getParameter("search");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM messages WHERE content LIKE ?");

            ps.setString(1, "%" + search + "%");

            ResultSet rs = ps.executeQuery();

            PrintWriter out = response.getWriter();

            out.println("<h2>Search Results</h2>");

            while (rs.next()) {
                out.println(rs.getString("content") + "<br>");
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}