package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/DeleteFileServlet")
public class DeleteFileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        try {
            int id = Integer.parseInt(request.getParameter("id"));

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "UPDATE files SET deleted=1 WHERE id=?"
            );

            ps.setInt(1, id);
            ps.executeUpdate();

            con.close();

            response.sendRedirect(request.getHeader("referer"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}