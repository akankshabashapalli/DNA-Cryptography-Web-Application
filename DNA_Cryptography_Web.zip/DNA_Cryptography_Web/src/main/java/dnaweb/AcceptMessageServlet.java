package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/acceptMessage")
public class AcceptMessageServlet extends HttpServlet {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String receiver = (String) session.getAttribute("user");
        String idStr = request.getParameter("id");

        if (idStr == null || idStr.trim().isEmpty()) {
            response.sendError(400, "Message id is required.");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            response.sendError(400, "Invalid message id.");
            return;
        }

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "UPDATE messages " +
                "SET status = 'accepted', read_at = NOW() " +
                "WHERE id = ? AND receiver = ? AND status = 'sent'"
            );
            ps.setInt(1, id);
            ps.setString(2, receiver);

            int updated = ps.executeUpdate();
            if (updated == 0) {
                response.sendError(400, "No matching pending message found.");
                return;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(500, "Database error: " + e.getMessage());
            return;
        }

        // Redirect receiver back to their dashboard
        response.sendRedirect("userDashboard.jsp");   // or ownerDashboard.jsp
    }
}