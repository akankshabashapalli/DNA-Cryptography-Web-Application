package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.annotation.*;

@WebServlet("/getFiles")
public class GetFilesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String user = (String) session.getAttribute("user");

        List<FileRow> files = new ArrayList<>();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project?useSSL=false&serverTimezone=UTC",
                "root", "@*akank321*@"
            );

            // Only use real columns: id, sender, receiver, filename, filedata_dna, sent_time
            String sql = "SELECT id, sender, receiver, filename, filedata_dna, sent_time " +
                         "FROM files WHERE deleted=0 AND receiver = ? ORDER BY sent_time DESC";

            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            rs = ps.executeQuery();

            while (rs.next()) {
                files.add(new FileRow(
                    rs.getInt("id"),
                    rs.getString("sender"),
                    rs.getString("receiver"),
                    rs.getString("filename"),
                    rs.getString("filedata_dna"),
                    rs.getString("sent_time")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (Exception e) {}
            if (ps != null) try { ps.close(); } catch (Exception e) {}
            if (con != null) try { con.close(); } catch (Exception e) {}
        }

        request.setAttribute("files", files);
        request.getRequestDispatcher("receiveFiles.jsp").forward(request, response);
    }
}