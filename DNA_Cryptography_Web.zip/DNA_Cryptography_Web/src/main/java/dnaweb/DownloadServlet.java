package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/DownloadServlet")
public class DownloadServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id;
        try {
            id = Integer.parseInt(request.getParameter("id"));
        } catch (NumberFormatException e) {
            response.sendError(400, "Invalid file ID.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

        	PreparedStatement ps = conn.prepareStatement(
        		    "SELECT filename, filedata_dna FROM files WHERE deleted=0 AND id=?");
            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                String filename = rs.getString("filename");
                String path = rs.getString("filedata_dna");

                String fullPath = getServletContext().getRealPath("/") + path;

                File file = new File(fullPath);

                if (!file.exists()) {
                    response.sendError(404, "File not found on server");
                    return;
                }

                FileInputStream fis = new FileInputStream(file);

                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition",
                        "attachment; filename=\"" + filename + "\"");

                OutputStream os = response.getOutputStream();

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }

                fis.close();
                os.close();

            } else {
                response.sendError(404, "File not found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(500, "Download error.");
        }
    }
}