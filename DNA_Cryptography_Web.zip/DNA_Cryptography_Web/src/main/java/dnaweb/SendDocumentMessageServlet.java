package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/sendDocumentMessage")
public class SendDocumentMessageServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String sender   = (String) session.getAttribute("user");
        String role     = (String) session.getAttribute("role");
        String receiver = request.getParameter("receiver");

        if (receiver == null || receiver.trim().isEmpty()) {
            response.sendError(400, "Receiver is required.");
            return;
        }

        Part filePart = request.getPart("file");
        if (filePart == null || filePart.getSize() == 0) {
            response.sendError(400, "File is required.");
            return;
        }

        String filename = filePart.getSubmittedFileName();
        if (filename == null || filename.trim().isEmpty()) {
            filename = "unknown";
        }

        byte[] fileData;
        try (InputStream in = filePart.getInputStream()) {
            fileData = in.readAllBytes();
        }

        System.out.println("DOCUMENT MESSAGE:");
        System.out.println("From: " + sender + " (" + role + ")");
        System.out.println("To: " + receiver);
        System.out.println("Filename: " + filename);
        System.out.println("Size: " + fileData.length + " bytes");

        /*
        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO file_messages(sender, receiver, filename, filedata, created_at) " +
                "VALUES (?, ?, ?, ?, NOW())");
            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, filename);
            ps.setBytes(4, fileData);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        */

        response.sendRedirect("userDashboard.jsp");   // or ownerDashboard.jsp
    }
}