package dnaweb;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.MultipartConfig;

import java.io.*;
import java.sql.*;

@WebServlet("/AdminReplyServlet")
@MultipartConfig
public class AdminReplyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ✅ FIX ENCODING
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {

            String message = request.getParameter("reply_msg");
            String complaintId = request.getParameter("id");

            Part filePart = request.getPart("file");

            String filePath = null;

            // ✅ HANDLE FILE UPLOAD
            if (filePart != null && filePart.getSize() > 0) {

                String fileName = filePart.getSubmittedFileName();
                fileName = new File(fileName).getName();

                String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                File dir = new File(uploadPath);

                if (!dir.exists()) dir.mkdirs();

                filePart.write(uploadPath + File.separator + fileName);

                filePath = "uploads/" + fileName;
            }

            Connection con = DBConnection.getConnection();

            // ✅ UPDATE COMPLAINT WITH REPLY
            PreparedStatement ps = con.prepareStatement(
                "UPDATE complaints SET reply_msg=?, reply_file=? WHERE id=?"
            );

            ps.setString(1, message);
            ps.setString(2, filePath);
            ps.setInt(3, Integer.parseInt(complaintId));

            ps.executeUpdate();

            response.sendRedirect("aboutComplaints.jsp?msg=reply");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}