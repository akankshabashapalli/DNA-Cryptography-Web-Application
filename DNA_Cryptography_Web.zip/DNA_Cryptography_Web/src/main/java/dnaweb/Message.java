package dnaweb;

public class Message {

    private String sender;
    private String messageText;
    private String status;
    private String createdAt;

    public Message(String sender, String messageText,
                   String status, String createdAt) {

        this.sender = sender;
        this.messageText = messageText;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getSender() {
        return sender;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getStatus() {
        return status;
    }

    public String getCreatedAt() {
        return createdAt;
    }
}