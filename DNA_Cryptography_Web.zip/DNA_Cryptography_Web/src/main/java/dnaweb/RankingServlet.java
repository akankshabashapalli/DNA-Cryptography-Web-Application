package dnaweb;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class RankingServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {

	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();

	    String keyword = request.getParameter("keyword");
	    String priorityStr = request.getParameter("priority");

	    out.println("Received: " + keyword + " " + priorityStr); // DEBUG

	    try {
	        int priority = Integer.parseInt(priorityStr);

	        Class.forName("com.mysql.cj.jdbc.Driver");

	        Connection con = DriverManager.getConnection(
	            "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@");

	        PreparedStatement ps = con.prepareStatement(
	            "INSERT INTO ranking(keyword, priority) VALUES (?, ?)");

	        ps.setString(1, keyword);
	        ps.setInt(2, priority);

	        int i = ps.executeUpdate();

	        if(i > 0){
	            out.println("<h3>Data Inserted Successfully ✅</h3>");
	        } else {
	            out.println("<h3>Insert Failed ❌</h3>");
	        }

	        con.close();

	    } catch (Exception e) {
	        out.println("<h3>Error: " + e + "</h3>"); // SHOW ERROR
	    }
	}
}