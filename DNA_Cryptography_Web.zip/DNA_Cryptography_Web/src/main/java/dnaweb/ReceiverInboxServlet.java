package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import java.util.*;

@WebServlet("/ReceiverInboxServlet")
public class ReceiverInboxServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        List<Map<String,String>> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            String user = (String) req.getSession().getAttribute("user");

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM messages WHERE receiver=? ORDER BY id DESC"
            );

            ps.setString(1, user);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String,String> m = new HashMap<>();

                m.put("sender", rs.getString("sender"));
                m.put("dna", rs.getString("message_text")); // ✅ IMPORTANT
                m.put("time", rs.getString("created_at"));

                list.add(m);
            }

            req.setAttribute("messages", list);

            // ✅ GET FROM SESSION
            HttpSession session = req.getSession();

            req.setAttribute("decryptedMessage",
                (String) session.getAttribute("decryptedMessage"));

            req.setAttribute("selectedDNA",
                (String) session.getAttribute("selectedDNA"));

            // ✅ CLEAR AFTER USE
            session.removeAttribute("decryptedMessage");
            session.removeAttribute("selectedDNA");

            RequestDispatcher rd =
                req.getRequestDispatcher("receiver_inbox.jsp");

            rd.forward(req, res);

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().write("Error: " + e.getMessage());
        }
    }
}