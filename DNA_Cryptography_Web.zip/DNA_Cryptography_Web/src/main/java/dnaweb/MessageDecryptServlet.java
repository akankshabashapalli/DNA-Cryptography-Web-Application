package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;

@WebServlet("/MessageDecryptServlet")
public class MessageDecryptServlet extends HttpServlet {

    // ✅ ADD THIS METHOD (missing in your code)
    private String unMutateDNA(String dna) {
        StringBuilder sb = new StringBuilder();

        for (char c : dna.toCharArray()) {
            switch (c) {
                case 'A' -> sb.append('T');
                case 'T' -> sb.append('A');
                case 'C' -> sb.append('G');
                case 'G' -> sb.append('C');
                default -> sb.append(c);
            }
        }
        return sb.toString();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            String dna = request.getParameter("dna");
            String key = request.getParameter("key");

            if (dna == null || key == null || key.isEmpty()) {
                response.getWriter().write("Invalid input");
                return;
            }

            // 🧬 STEP 1: Reverse
            dna = new StringBuilder(dna).reverse().toString();

            // 🧬 STEP 2: Unmutate
            dna = unMutateDNA(dna);

            // 🧬 STEP 3: DNA → bytes
            byte[] encrypted = DNAUtil.dnaToBytes(dna);

            // 🔐 STEP 4: XOR DECRYPT
            ByteArrayOutputStream xorOut = new ByteArrayOutputStream();

            for (int i = 0; i < encrypted.length; i++) {

                int val = encrypted[i] & 0xFF;
                int k = key.charAt(i % key.length());

                val ^= 170;
                val = val - k;

                if (val < 0) val += 256;

                xorOut.write(val);
            }

            byte[] xorDecrypted = xorOut.toByteArray();

            // 🔐 STEP 5: AES DECRYPT
            byte[] resultBytes = AESUtil.decrypt(xorDecrypted, key);

            String result = new String(resultBytes);

            // 🔐 STEP 6: CHECK SIGNATURE
            if (!result.startsWith("DNA_SECURE:")) {
                response.getWriter().write("❌ WRONG KEY");
                return;
            }

            // ✂ REMOVE SIGNATURE
            result = result.replace("DNA_SECURE:", "");

            // ✅ SEND RESULT
            request.setAttribute("decryptedText", result);

            request.getRequestDispatcher("chat.jsp")
                   .forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Decryption Error: " + e.getMessage());
        }
    }

    // ✅ FIX 405 ERROR
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}