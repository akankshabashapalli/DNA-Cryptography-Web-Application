package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/aboutFiles")
public class AboutFilesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("role"))) {
            response.sendRedirect("index.jsp");
            return;
        }

        List<FileRow> files = new ArrayList<>();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project?useSSL=false&serverTimezone=UTC",
                "root", "@*akank321*@"
            );

            String sql = "SELECT id, filename, username, upload_time, size, encstatus " +
                         "FROM files WHERE deleted=0 ORDER BY upload_time DESC";

            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                files.add(new FileRow(
                    rs.getInt("id"),
                    rs.getString("filename"),
                    rs.getString("username"),
                    rs.getString("upload_time"),
                    rs.getString("size"),
                    rs.getString("encstatus")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (rs != null) try { rs.close(); } catch (Exception e) {}
            if (ps != null) try { ps.close(); } catch (Exception e) {}
            if (con != null) try { con.close(); } catch (Exception e) {}
        }

        request.setAttribute("files", files);
        request.getRequestDispatcher("aboutFiles.jsp").forward(request, response);
    }
}