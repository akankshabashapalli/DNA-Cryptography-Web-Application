package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/admin/messages")
public class AdminMessagesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("role"))) {
            response.sendError(403, "Access denied.");
            return;
        }

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        // JSON structure: [ { sender, message, complaint } ]
        out.print("[");
        boolean first = true;

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(
                "SELECT sender, message, is_complaint FROM messages " +
                "WHERE receiver = 'admin' " +
                "ORDER BY id DESC"
            );

            while (rs.next()) {
                if (!first) out.print(",");
                first = false;

                String sender   = rs.getString("sender");
                String message  = rs.getString("message");
                boolean isComp  = rs.getBoolean("is_complaint");

                message = message.replace("\"", "\\\"");

                out.printf(
                    "{\"sender\":\"%s\",\"message\":\"%s\",\"complaint\":%b}",
                    sender, message, isComp
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("]");
    }
}