package dnaweb;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ReplyServlet")
public class ReplyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String sender = "admin";  // ✅ IMPORTANT
        String receiver = request.getParameter("receiver");
        String filename = request.getParameter("filename");

        System.out.println("ADMIN replying to: " + receiver);

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO files (sender, receiver, filename, filedata_dna, sent_time) VALUES (?, ?, ?, ?, NOW())"
            );

            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, filename);
            ps.setString(4, "reply_file"); // dummy or actual path

            int i = ps.executeUpdate();

            if (i > 0) {
                System.out.println("✅ Reply sent successfully");
            } else {
                System.out.println("❌ Reply failed");
            }

            response.sendRedirect("adminComplaints.jsp?msg=reply");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}