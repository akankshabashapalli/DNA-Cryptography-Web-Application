package dnaweb;

import java.util.*;

public class UserDatabase {

    // 👤 User storage
    private static Map<String, String> users = new HashMap<>();
    private static Map<String, String> roles = new HashMap<>();

    // 📁 File storage
    private static List<Map<String, String>> files = new ArrayList<>();

    // ✅ Add user
    public static void addUser(String username, String password, String role, Map<String, String> details) {
        users.put(username, password);
        roles.put(username, role);
    }

    // ✅ Validate user
    public static boolean validateUser(String username, String password, String role) {
        if (!users.containsKey(username)) return false;

        return password.equals(users.get(username)) && role.equals(roles.get(username));
    }

    // ✅ Get users
    public static Map<String, String> getUsers() {
        return users;
    }

    // ✅ Get roles
    public static Map<String, String> getRoles() {
        return roles;
    }

    // ✅ Add file
    public static void addFile(Map<String, String> fileDetails) {
        files.add(fileDetails);
    }
    public static List<Map<String, String>> searchFiles(String keyword) {
        List<Map<String, String>> result = new ArrayList<>();

        for (Map<String, String> file : files) {
            String filename = file.get("filename");

            if (filename != null && filename.toLowerCase().contains(keyword.toLowerCase())) {
                result.add(file);
            }
        }

        return result;
    }
    // ✅ Get all files
    public static List<Map<String, String>> getAllFiles() {
        return files;
    }
}