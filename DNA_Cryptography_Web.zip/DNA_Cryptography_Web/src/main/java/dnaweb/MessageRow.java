package dnaweb;

public class MessageRow {

    private int id;
    private String sender;
    private String receiver;
    private String messageText;
    private String status;
    private String sentTime;
    private String readTime;

    public MessageRow(int id, String sender, String receiver,
                      String messageText, String status,
                      String sentTime, String readTime) {
        this.id = id;
        this.sender = sender;
        this.receiver = receiver;
        this.messageText = messageText;
        this.status = status;
        this.sentTime = sentTime;
        this.readTime = readTime;
    }

    public int getId()           { return id; }
    public String getSender()    { return sender; }
    public String getReceiver()  { return receiver; }
    public String getMessageText(){ return messageText; }
    public String getStatus()    { return status; }
    public String getSentTime()  { return sentTime; }
    public String getReadTime()  { return readTime; }
}