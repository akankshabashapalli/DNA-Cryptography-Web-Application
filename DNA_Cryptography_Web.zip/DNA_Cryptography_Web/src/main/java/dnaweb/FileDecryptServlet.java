package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/FileDecryptServlet")
public class FileDecryptServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        try {
            String key = request.getParameter("key");
            String id = request.getParameter("id");

            if (key == null || key.isEmpty()) {
                response.getWriter().write("❌ Key required");
                return;
            }

            if (id == null || id.isEmpty()) {
                response.getWriter().write("❌ File ID missing");
                return;
            }

            // ✅ CONNECT DATABASE
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT filedata_dna FROM files WHERE id=?"
            );
            ps.setInt(1, Integer.parseInt(id));

            ResultSet rs = ps.executeQuery();

            String filePath = null;

            if (rs.next()) {
                filePath = rs.getString("filedata_dna"); // e.g. uploads/filename.txt
            } else {
                response.getWriter().write("❌ File not found");
                return;
            }

            con.close();

            // ✅ FIXED PATH (IMPORTANT)
            String fullPath = getServletContext().getRealPath("/") + filePath;

            System.out.println("Reading file from: " + fullPath);

            File f = new File(fullPath);
            if (!f.exists() || f.length() == 0) {
                response.getWriter().write("❌ File missing or empty");
                return;
            }

            // ✅ READ FILE CONTENT (DNA)
            BufferedReader br = new BufferedReader(new FileReader(f));

            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                sb.append(line);
            }

            br.close();

            String dna = sb.toString();

            if (dna.isEmpty()) {
                response.getWriter().write("❌ Empty DNA data");
                return;
            }

            // 🧬 STEP 1: REVERSE
            dna = new StringBuilder(dna).reverse().toString();

            // 🧬 STEP 2: UNMUTATE
            dna = DNAUtil.unmutate(dna);

            // 🧬 STEP 3: DNA → BYTES
            byte[] encrypted = DNAUtil.dnaToBytes(dna);

            System.out.println("Encrypted bytes: " + encrypted.length);

            if (encrypted.length == 0) {
                response.getWriter().write("❌ Conversion failed");
                return;
            }

            // 🔐 STEP 4: XOR DECRYPT
            ByteArrayOutputStream xorOut = new ByteArrayOutputStream();

            for (int i = 0; i < encrypted.length; i++) {
                int val = encrypted[i] & 0xFF;
                int k = key.charAt(i % key.length());

                val ^= 170;
                val = val - k;

                if (val < 0) val += 256;

                xorOut.write(val);
            }

            byte[] xorDecrypted = xorOut.toByteArray();

            System.out.println("After XOR: " + xorDecrypted.length);

            // 🔐 STEP 5: AES DECRYPT
            byte[] result = AESUtil.decrypt(xorDecrypted, key);

            System.out.println("After AES: " + (result != null ? result.length : 0));

            if (result == null || result.length < 10) {
                response.getWriter().write("❌ Decryption failed (wrong key or corrupted file)");
                return;
            }

            // 🔐 STEP 6: VERIFY SIGNATURE
            String signature = "DNA_SECURE";

            if (result.length < signature.length()) {
                response.getWriter().write("❌ Invalid decrypted data");
                return;
            }

            String check = new String(result, 0, signature.length());

            if (!check.equals(signature)) {
                response.getWriter().write("❌ WRONG KEY");
                return;
            }

            // ✂ REMOVE SIGNATURE
            byte[] finalData = new byte[result.length - signature.length()];
            System.arraycopy(result, signature.length(), finalData, 0, finalData.length);

            // 📥 DOWNLOAD FILE
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition",
                    "attachment; filename=\"decrypted_file\"");

            OutputStream os = response.getOutputStream();
            os.write(finalData);
            os.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("❌ Decryption Error: " + e.getMessage());
        }
    }
}