package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/sendPendingMessage")
public class SendPendingMessageServlet extends HttpServlet {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        String sender   = (String) session.getAttribute("user");
        String receiver = request.getParameter("receiver");
        String message  = request.getParameter("message");

        if (receiver == null || receiver.trim().isEmpty()) {
            response.sendError(400, "Receiver is required.");
            return;
        }

        if (message == null || message.trim().isEmpty()) {
            response.sendError(400, "Message text is required.");
            return;
        }

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO messages(sender, receiver, message_text, status, created_at) " +
                "VALUES (?, ?, ?, 'sent', NOW())"
            );
            ps.setString(1, sender);
            ps.setString(2, receiver);
            ps.setString(3, message);
            ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(500, "Database error: " + e.getMessage());
            return;
        }

        // Redirect sender back to their dashboard
        response.sendRedirect("userDashboard.jsp");   // or ownerDashboard.jsp
    }
}