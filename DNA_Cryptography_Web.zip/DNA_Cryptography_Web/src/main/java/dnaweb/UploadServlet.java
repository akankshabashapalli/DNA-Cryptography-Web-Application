package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet("/UploadServlet")
@MultipartConfig
public class UploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");

        try {
            // ✅ SESSION USER
            HttpSession session = request.getSession();
            String sender = (String) session.getAttribute("user");

            if (sender == null) {
                response.getWriter().println("User not logged in ❌");
                return;
            }

            // ✅ RECEIVER
            String receiver = request.getParameter("receiver");

            if (receiver == null || receiver.trim().isEmpty()) {
                response.getWriter().println("Receiver is required ❌");
                return;
            }

            // ✅ MESSAGE (for complaint)
            String message = request.getParameter("message");
            if (message == null || message.trim().isEmpty()) {
                message = "No message";
            }

            // ✅ FILE PART
            Part filePart = request.getPart("file");

            String fileName = "";
            String uniqueName = "";
            String dbPath = "";

            // ✅ FILE OPTIONAL (ONLY SAVE IF EXISTS)
            if (filePart != null && filePart.getSize() > 0) {

                fileName = filePart.getSubmittedFileName();
                fileName = new File(fileName).getName();

                String uploadPath = getServletContext().getRealPath("") + File.separator + "uploads";
                File uploadDir = new File(uploadPath);

                if (!uploadDir.exists()) {
                    uploadDir.mkdirs();
                }

                uniqueName = System.currentTimeMillis() + "_" + fileName;

                filePart.write(uploadPath + File.separator + uniqueName);

                dbPath = "uploads/" + uniqueName;
            }

            // ✅ DB CONNECTION
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/dna_project",
                    "root",
                    "@*akank321*@"
            );

            int result = 0;

            // ============================
            // 🔥 COMPLAINT (ADMIN)
            // ============================
            if (receiver.equalsIgnoreCase("admin")) {

                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO complaints (sender, receiver, message, file_path, sent_time) VALUES (?, ?, ?, ?, NOW())"
                );

                ps.setString(1, sender);
                ps.setString(2, receiver);
                ps.setString(3, message);
                ps.setString(4, dbPath); // can be empty

                result = ps.executeUpdate();
            }

            // ============================
            // 📁 NORMAL FILE SEND
            // ============================
            else {

                // ❗ REQUIRE FILE HERE
                if (filePart == null || filePart.getSize() == 0) {
                    response.getWriter().println("Please select a file ❌");
                    return;
                }

                // 🔹 DUPLICATE CHECK
                PreparedStatement check = con.prepareStatement(
                        "SELECT * FROM files WHERE sender=? AND filename=?"
                );

                check.setString(1, sender);
                check.setString(2, fileName);

                ResultSet rsCheck = check.executeQuery();

                if (rsCheck.next()) {
                    response.sendRedirect("upload.jsp?msg=duplicate");
                    return;
                }

             
                // 🔹 SAVE TO DB
                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO files (sender, receiver, filename, filedata_dna, sent_time) VALUES (?, ?, ?, ?, NOW())"
                );

                ps.setString(1, sender);
                ps.setString(2, receiver);
                ps.setString(3, fileName);
                ps.setString(4, dbPath);

                result = ps.executeUpdate();
            }

            con.close();

            // ✅ REDIRECT
            if (result > 0) {
                response.sendRedirect("userDashboard.jsp?msg=success");
            } else {
                response.sendRedirect("userDashboard.jsp?msg=error");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println(
                    "<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>"
            );
        }
    }
}