package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/admin/stats")
public class AdminStatsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equals(session.getAttribute("role"))) {
            response.sendError(403, "Access denied.");
            return;
        }

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        // structure: { totalUsers, totalFiles, recentUploads: [...] }
        out.print("{");

        int totalUsers = 0;
        int totalFiles = 0;

        List<Upload> recentUploads = new ArrayList<>();

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            // Total users
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM users")) {
                if (rs.next()) {
                    totalUsers = rs.getInt(1);
                }
            }

            // Total files (all users)
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM files")) {
                if (rs.next()) {
                    totalFiles = rs.getInt(1);
                }
            }

            // Recent uploads (last 5)
            try (Statement stmt = con.createStatement();
                 ResultSet rs = stmt.executeQuery(
                     "SELECT filename, owner_username, created_at " +
                     "FROM files WHERE deleted=0 ORDER BY created_at DESC LIMIT 5")) {

                while (rs.next()) {
                    recentUploads.add(new Upload(
                        rs.getString("filename"),
                        rs.getString("owner_username"),
                        rs.getString("created_at")
                    ));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.printf(
            "\"totalUsers\":%d,\"totalFiles\":%d,\"recentUploads\":[",
            totalUsers, totalFiles
        );

        boolean first = true;
        for (Upload u : recentUploads) {
            if (!first) out.print(",");
            first = false;

            out.printf(
                "{\"filename\":\"%s\",\"owner\":\"%s\",\"time\":\"%s\"}",
                u.filename.replace("\"", "\\\""),
                u.owner.replace("\"", "\\\""),
                u.time.replace("\"", "\\\"")
            );
        }

        out.print("]}");
    }

    // Simple helper class to hold upload data
    private static class Upload {
        String filename, owner, time;
        Upload(String filename, String owner, String time) {
            this.filename = filename;
            this.owner = owner;
            this.time = time;
        }
    }
}