package dnaweb;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ComplaintServlet")
public class ComplaintServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ✅ ADD HERE (TOP - BEFORE getParameter)
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String sender = (String) request.getSession().getAttribute("user");
        String message = request.getParameter("message");

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO complaints (sender, message, sent_time) VALUES (?, ?, NOW())"
            );

            ps.setString(1, sender);
            ps.setString(2, message);

            ps.executeUpdate();

            response.sendRedirect("complaint.jsp?success=1");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}