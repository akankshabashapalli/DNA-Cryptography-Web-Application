package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import jakarta.servlet.annotation.*;

@WebServlet("/AcceptConnectionServlet")
public class AcceptConnectionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String user = (String) session.getAttribute("user");
        String other = request.getParameter("other");

        if (other == null || other.isEmpty()) {
            response.getWriter().print("Missing 'other' user.");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project?useSSL=false&serverTimezone=UTC",
                "root", "@*akank321*@"
            );

            // 1. If row already exists (pending), update status to accepted
            String sqlUpdate = """
                UPDATE connections
                SET status = 'accepted'
                WHERE sender = ? AND receiver = ? AND status = 'pending'
                """;

            ps = con.prepareStatement(sqlUpdate);
            ps.setString(1, user);
            ps.setString(2, other);
            ps.executeUpdate();

            // 2. Insert the reverse direction if not exists
            String sqlInsert = """
                INSERT IGNORE INTO connections (sender, receiver, status)
                VALUES (?, ?, 'accepted')
                """;

            ps = con.prepareStatement(sqlInsert);
            ps.setString(1, other);
            ps.setString(2, user);
            ps.executeUpdate();

            response.sendRedirect("connections.jsp");  // or your dashboard

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().print("Failed to accept connection.");
        } finally {
            if (ps != null) try { ps.close(); } catch (Exception e) {}
            if (con != null) try { con.close(); } catch (Exception e) {}
        }
    }
}