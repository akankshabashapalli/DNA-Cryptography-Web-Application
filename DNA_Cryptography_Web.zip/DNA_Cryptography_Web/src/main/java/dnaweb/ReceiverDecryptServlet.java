package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

@WebServlet("/ReceiverDecryptServlet")
public class ReceiverDecryptServlet extends HttpServlet {

    private byte[] dnaToBytes(String dna) {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        for (int i = 0; i < dna.length(); i += 4) {

            int value = 0;

            for (int j = 0; j < 4; j++) {
                value <<= 2;

                char c = dna.charAt(i + j);

                if (c == 'A') value |= 0;
                else if (c == 'C') value |= 1;
                else if (c == 'G') value |= 2;
                else if (c == 'T') value |= 3;
            }

            out.write((byte) value);
        }

        return out.toByteArray();
    }

    private String reverseMutate(String dna) {

        StringBuilder original = new StringBuilder();

        for (char c : dna.toCharArray()) {
            switch (c) {
                case 'A': original.append('T'); break;
                case 'T': original.append('A'); break;
                case 'C': original.append('G'); break;
                case 'G': original.append('C'); break;
            }
        }

        return original.toString();
    }

    private String dnaToText(String dna, String keyStr) {

        byte[] key = keyStr.getBytes(StandardCharsets.UTF_8);

        dna = new StringBuilder(dna).reverse().toString();
        dna = reverseMutate(dna);

        byte[] bytes = dnaToBytes(dna);

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        for (int i = 0; i < bytes.length; i++) {

            int val = bytes[i] & 0xFF;

            val = ((val >> 3) | (val << 5)) & 0xFF;
            val = val ^ key[i % key.length];
            val = val ^ 170;

            out.write((byte) val);
        }

        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String dna = request.getParameter("dna");
        String key = request.getParameter("key");

        if (dna == null || dna.isEmpty() || key == null || key.isEmpty()) {
            response.getWriter().write("❌ Missing DNA or Key!");
            return;
        }

        String message;

        try {
            message = dnaToText(dna.trim(), key.trim());
        } catch (Exception e) {
            message = "❌ Wrong Key or Corrupted Data!";
        }

        // ✅ STORE IN SESSION (IMPORTANT FIX)
        HttpSession session = request.getSession();
        session.setAttribute("decryptedMessage", message);
        session.setAttribute("selectedDNA", dna);

        // ✅ REDIRECT (NOT FORWARD)
        response.sendRedirect("ReceiverInboxServlet");
    }
}