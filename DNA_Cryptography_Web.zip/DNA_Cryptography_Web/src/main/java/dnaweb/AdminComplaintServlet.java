package dnaweb;

import java.io.IOException;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AdminComplaintServlet")
public class AdminComplaintServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String, String>> complaints = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM complaints ORDER BY id DESC"
            );

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> c = new HashMap<>();

                c.put("sender", rs.getString("sender"));
                c.put("receiver", rs.getString("receiver"));
                c.put("message", rs.getString("message"));
                c.put("file_path", rs.getString("file_path"));
                c.put("sent_time", rs.getString("sent_time"));

                complaints.add(c);
            }

            request.setAttribute("complaints", complaints);
            request.getRequestDispatcher("aboutComplaints.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}