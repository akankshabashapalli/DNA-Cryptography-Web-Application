package dnaweb;

import java.util.Date;

public class UploadedFile {
    private String fileId;
    private String fileName;
    private String uploadedBy;
    private String category;
    private String encryptionKey;
    private Date uploadDate;

    public UploadedFile(String fileId, String fileName, String uploadedBy,
                        String category, String encryptionKey, Date uploadDate) {
        this.fileId = fileId;
        this.fileName = fileName;
        this.uploadedBy = uploadedBy;
        this.category = category;
        this.encryptionKey = encryptionKey;
        this.uploadDate = uploadDate;
    }

    // Getters and Setters
    public String getFileId() { return fileId; }
    public void setFileId(String fileId) { this.fileId = fileId; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(String uploadedBy) { this.uploadedBy = uploadedBy; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getEncryptionKey() { return encryptionKey; }
    public void setEncryptionKey(String encryptionKey) { this.encryptionKey = encryptionKey; }

    public Date getUploadDate() { return uploadDate; }
    public void setUploadDate(Date uploadDate) { this.uploadDate = uploadDate; }
}