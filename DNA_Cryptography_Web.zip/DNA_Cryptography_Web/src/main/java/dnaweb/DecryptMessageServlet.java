package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;

@WebServlet("/DecryptMessageServlet")
public class DecryptMessageServlet extends HttpServlet {

    private byte[] dnaToBytes(String dna) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        for (int i = 0; i < dna.length(); i += 4) {

            int value = 0;

            for (int j = 0; j < 4; j++) {

                char c = dna.charAt(i + j);

                int bits;
                if (c == 'A') bits = 0;
                else if (c == 'C') bits = 1;
                else if (c == 'G') bits = 2;
                else bits = 3;

                value |= (bits << (6 - j * 2));
            }

            baos.write(value);
        }

        return baos.toByteArray();
    }

    private String reverseMutate(String dna) {

        StringBuilder original = new StringBuilder();

        for (char c : dna.toCharArray()) {

            if (c == 'A') original.append('T');
            else if (c == 'T') original.append('A');
            else if (c == 'C') original.append('G');
            else if (c == 'G') original.append('C');
        }

        return original.toString();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String dna = request.getParameter("dna");
        String keyStr = request.getParameter("key");

        if (dna == null || keyStr == null || keyStr.isEmpty()) {
            response.getWriter().println("Invalid input.");
            return;
        }

        dna = new StringBuilder(dna).reverse().toString();
        dna = reverseMutate(dna);

        byte[] encrypted = dnaToBytes(dna);
        byte[] key = keyStr.getBytes("UTF-8");

        ByteArrayOutputStream output = new ByteArrayOutputStream();

        for (int i = 0; i < encrypted.length; i++) {

            int val = encrypted[i] & 0xFF;

            val = ((val >> 3) | (val << 5)) & 0xFF;
            val = val ^ key[i % key.length];
            val = val ^ 170;

            output.write((byte) val);
        }

        String message = new String(output.toByteArray(), "UTF-8");

        request.setAttribute("message", message);

        RequestDispatcher rd = request.getRequestDispatcher("/GetMessagesServlet");
        rd.forward(request, response);
    }
}