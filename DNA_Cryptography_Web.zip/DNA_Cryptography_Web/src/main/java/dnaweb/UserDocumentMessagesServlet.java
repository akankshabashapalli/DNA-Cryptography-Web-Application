package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/user/documentMessages")
public class UserDocumentMessagesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendError(403, "Access denied.");
            return;
        }

        String receiver = (String) session.getAttribute("user");   // owner receives

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        out.print("[");
        boolean first = true;

        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/dna_project", "root", "@*akank321*@")) {

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, sender, filename, created_at, LENGTH(filedata) AS size " +
                "FROM file_messages " +
                "WHERE receiver = ? " +
                "ORDER BY id DESC"
            );
            ps.setString(1, receiver);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                if (!first) out.print(",");
                first = false;

                int id         = rs.getInt("id");
                String sender   = rs.getString("sender");
                String filename = rs.getString("filename");
                String time     = rs.getString("created_at");
                long size       = rs.getLong("size");

                filename = filename.replace("\"", "\\\"");

                out.printf(
                    "{"
                    + "\"id\":%d,"
                    + "\"sender\":\"%s\","
                    + "\"filename\":\"%s\","
                    + "\"time\":\"%s\","
                    + "\"size\":%d"
                    + "}",
                    id, sender, filename, time, size
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.print("]");
    }
}