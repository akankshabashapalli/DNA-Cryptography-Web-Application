package dnaweb;

public class DNAUtil {

    public static String bytesToDNA(byte[] data) {
        StringBuilder dna = new StringBuilder();

        for (byte b : data) {
            int val = b & 0xFF;

            for (int i = 6; i >= 0; i -= 2) {
                int bits = (val >> i) & 3;

                switch (bits) {
                    case 0 -> dna.append('A');
                    case 1 -> dna.append('C');
                    case 2 -> dna.append('G');
                    case 3 -> dna.append('T');
                }
            }
        }
        return dna.toString();
    }

    public static byte[] dnaToBytes(String dna) {
        dna = dna.replaceAll("\\s", "");

        if (dna.length() % 4 != 0)
            throw new RuntimeException("Invalid DNA");

        byte[] data = new byte[dna.length() / 4];

        for (int i = 0; i < dna.length(); i += 4) {
            int value = 0;

            for (int j = 0; j < 4; j++) {
                char c = dna.charAt(i + j);

                int bits = switch (c) {
                    case 'A' -> 0;
                    case 'C' -> 1;
                    case 'G' -> 2;
                    case 'T' -> 3;
                    default -> 0;
                };

                value |= (bits << (6 - j * 2));
            }

            data[i / 4] = (byte) value;
        }
        return data;
    }

    public static String mutate(String dna) {
        StringBuilder sb = new StringBuilder();

        for (char c : dna.toCharArray()) {
            switch (c) {
                case 'A' -> sb.append('T');
                case 'T' -> sb.append('A');
                case 'C' -> sb.append('G');
                case 'G' -> sb.append('C');
            }
        }
        return sb.toString();
    }

    public static byte[] xorEncrypt(byte[] data, String key) {
        byte[] out = new byte[data.length];

        for (int i = 0; i < data.length; i++) {
            int val = data[i] & 0xFF;
            int k = key.charAt(i % key.length());

            val = val + k;
            val ^= 170;

            out[i] = (byte) val;
        }
        return out;
    }
    public static String unmutate(String dna) {
        StringBuilder result = new StringBuilder();

        for (char c : dna.toCharArray()) {
            switch (c) {
                case 'A': result.append('T'); break;
                case 'T': result.append('A'); break;
                case 'C': result.append('G'); break;
                case 'G': result.append('C'); break;
            }
        }
        return result.toString();
    }
}