package dnaweb;

import java.io.*;
import java.sql.*;
import java.util.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ReceiveFilesServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Map<String,Object>> fileList = new ArrayList<>();

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            String user = (String) request.getSession().getAttribute("user");
            if (user == null) {
                response.sendRedirect("index.jsp");
                return;
            }

            con = DBConnection.getConnection();
            ps = con.prepareStatement(
                "SELECT * FROM files WHERE deleted=0 AND receiver = ? ORDER BY sent_time DESC"
            );
            ps.setString(1, user);
            rs = ps.executeQuery();

            while (rs.next()) {
                Map<String,Object> row = new HashMap<>();
                row.put("id", rs.getInt("id"));
                row.put("sender", rs.getString("sender"));
                row.put("filename", rs.getString("filename"));
                row.put("keyval", rs.getString("keyval"));
                row.put("sent_time", rs.getString("sent_time"));
                fileList.add(row);
            }

            request.setAttribute("fileList", fileList);
            request.getRequestDispatcher("receiveFiles.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
            request.getRequestDispatcher("receiveFiles.jsp").forward(request, response);
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) {}
            if (ps != null) try { ps.close(); } catch (SQLException e) {}
            if (con != null) try { con.close(); } catch (SQLException e) {}
        }
    }
}