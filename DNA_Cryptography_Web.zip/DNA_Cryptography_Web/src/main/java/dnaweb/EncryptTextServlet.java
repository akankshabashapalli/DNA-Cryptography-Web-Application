package dnaweb;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/EncryptTextServlet")
public class EncryptTextServlet extends HttpServlet {

    private static final String CHARSET =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?/ ";

    // ✅ Handle POST
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        process(request, response);
    }

    // ✅ Handle GET (IMPORTANT FIX for 405 error)
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        process(request, response);
    }

    private void process(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String text = request.getParameter("message");
        String keyInput = request.getParameter("key");

        if (text == null || keyInput == null || keyInput.isEmpty()) {
            out.println("Enter message and key.");
            return;
        }

        int[] key = new int[keyInput.length()];
        for (int i = 0; i < keyInput.length(); i++) {
            key[i] = keyInput.charAt(i);
        }

        StringBuilder encrypted = new StringBuilder();

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            int index = CHARSET.indexOf(ch);

            if (index == -1) {
                encrypted.append(ch);
                continue;
            }

            int k = key[i % key.length];
            int cipherIndex = (index + k) % CHARSET.length();

            encrypted.append(CHARSET.charAt(cipherIndex));
        }

        out.println("<h2>Encrypted Text:</h2>");
        out.println("<textarea rows='5' cols='50'>" + encrypted + "</textarea>");
    }
}