package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/CloudServlet")
public class CloudServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, sender, receiver, filename, sent_time FROM files WHERE deleted=0 ORDER BY id DESC"
            );

            ResultSet rs = ps.executeQuery();

            List<Map<String, String>> list = new ArrayList<>();

            while (rs.next()) {
                Map<String, String> map = new HashMap<>();

                map.put("id", String.valueOf(rs.getInt("id")));
                map.put("sender", rs.getString("sender"));
                map.put("receiver", rs.getString("receiver"));
                map.put("filename", rs.getString("filename"));
                map.put("sent_time", rs.getString("sent_time"));

                list.add(map);
            }

            request.setAttribute("files", list);

            RequestDispatcher rd = request.getRequestDispatcher("cloudDetails.jsp");
            rd.forward(request, response);

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}