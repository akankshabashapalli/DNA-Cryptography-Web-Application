package dnaweb;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/FileEncryptServlet")
@MultipartConfig
public class FileEncryptServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            Part filePart = request.getPart("file");
            String key = request.getParameter("key");
            String receiver = request.getParameter("receiver");

            if (key == null || key.isEmpty()) {
                response.getWriter().write("❌ Key required");
                return;
            }

            // 📥 Read file
            InputStream is = filePart.getInputStream();
            byte[] fileBytes = is.readAllBytes();

            // 🔐 STEP 0: ADD SIGNATURE
            String signature = "DNA_SECURE";
            byte[] sig = signature.getBytes();

            byte[] combined = new byte[sig.length + fileBytes.length];
            System.arraycopy(sig, 0, combined, 0, sig.length);
            System.arraycopy(fileBytes, 0, combined, sig.length, fileBytes.length);

            // 🔐 STEP 1: AES ENCRYPT
            byte[] aesEncrypted = AESUtil.encrypt(combined, key);

            // 🔐 STEP 2: XOR ENCRYPT
            byte[] xorEncrypted = DNAUtil.xorEncrypt(aesEncrypted, key);

            // 🧬 STEP 3: BYTES → DNA
            String dna = DNAUtil.bytesToDNA(xorEncrypted);

            // 🧬 STEP 4: MUTATE
            dna = DNAUtil.mutate(dna);

            // 🧬 STEP 5: REVERSE
            dna = new StringBuilder(dna).reverse().toString();
         // ☁ SAVE DNA TO uploads FOLDER
            String uploadPath = getServletContext().getRealPath("/uploads/");

            File folder = new File(uploadPath);
            if (!folder.exists()) {
                folder.mkdir();
            }

            // make filename unique
            String fileName = System.currentTimeMillis() + "_" + filePart.getSubmittedFileName() + ".txt";

            String filePath = uploadPath + File.separator + fileName;

            FileWriter fw = new FileWriter(filePath);
            fw.write(dna);
            fw.close();

            // 💾 STORE IN DB
            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO files(sender, receiver, filename, filedata_dna) VALUES (?, ?, ?, ?)"
            );

            ps.setString(1, (String) request.getSession().getAttribute("user"));
            ps.setString(2, receiver);
            ps.setString(3, filePart.getSubmittedFileName());
            ps.setString(4, "uploads/" + fileName);   // ✅ store DNA in correct column

            ps.executeUpdate();
            con.close();

            response.sendRedirect("success.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("❌ Encryption Error: " + e.getMessage());
        }
    }
}