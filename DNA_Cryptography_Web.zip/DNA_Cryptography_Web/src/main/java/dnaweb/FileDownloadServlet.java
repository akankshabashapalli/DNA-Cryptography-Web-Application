package dnaweb;

import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.*;

@MultipartConfig
public class FileDownloadServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	request.setCharacterEncoding("UTF-8");
    	response.setContentType("text/html;charset=UTF-8");
        int fileId = Integer.parseInt(request.getParameter("id"));

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBConnection.getConnection();
            ps = con.prepareStatement(
                "SELECT filepath, keyval, sender, receiver FROM files WHERE id = ?"
            );
            ps.setInt(1, fileId);
            rs = ps.executeQuery();

            if (rs.next()) {
                String filepath = rs.getString("filepath");
                String key = rs.getString("keyval");
                String sender = rs.getString("sender");
                String receiver = rs.getString("receiver");

                File f = new File(filepath);
                if (!f.exists()) {
                    response.getWriter().println("File not found.");
                    return;
                }

                // Set response for file download
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition",
                    "attachment; filename=\"" + f.getName() + "\"");

                // Decrypt if needed (you can add DNA decrypt here)
                // For now, just send the file

                FileInputStream fin = new FileInputStream(f);
                ServletOutputStream sos = response.getOutputStream();
                byte[] buffer = new byte[4096];
                int len;
                while ((len = fin.read(buffer)) > 0) {
                    sos.write(buffer, 0, len);
                }
                fin.close();
                sos.close();

            } else {
                response.getWriter().println("No such file.");
            }

        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            if (rs != null) try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (ps != null) try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
            if (con != null) try { con.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}